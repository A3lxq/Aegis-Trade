<p align="center">
  <img src="assets/icon.png" width="96" height="96" alt="Aegis-Trade Logo" />
</p>

<h1 align="center">Aegis-Trade</h1>
<p align="center"><b>Autonomous AI Trading Platform — Android APK</b></p>
<p align="center">
  <img src="https://img.shields.io/badge/version-2.5.0-00d4aa?style=flat-square" />
  <img src="https://img.shields.io/badge/platform-Android-3DDC84?style=flat-square&logo=android" />
  <img src="https://img.shields.io/badge/built%20with-Expo%20%2B%20React%20Native-0099ff?style=flat-square" />
  <img src="https://img.shields.io/badge/AI-Claude%20API-9b59ff?style=flat-square" />
</p>

---

## Overview

**Aegis-Trade** is an autonomous AI-powered trading platform that connects to your **TradingView** account for chart analysis and your **MetaTrader 5** account for trade execution. Simply log in to both platforms and let the AI handle the rest — analysing markets, generating signals, and executing trades to maximise profits.

The **Gold Scalper module** is a dedicated XAUUSD (gold) scalping engine with live M5 candlestick charts, session tracking, AI-generated scalp signals, and real-time P&L monitoring.

---

## Features

| Module | Description |
|---|---|
| ◉ **Dashboard** | Live charts for 8 symbols, AI signals, open positions, market scanner, equity curve |
| 🥇 **Gold Scalper** | Dedicated XAUUSD module — M5 chart, EMA 8/21, 4 session tracker, AI scalp signals with TP1/TP2, quick trade panel, 5 curated setups, economic news calendar |
| ⚙ **Strategies** | Write strategies in plain English or upload files. AI gives full insights (strengths, weaknesses, rating/10) **before** you backtest |
| 📊 **History** | Full trade history log with win/loss filter and AI performance review |
| ⚡ **AI Chat** | Multi-turn Claude AI trading assistant — market analysis, strategy help, risk management |
| 🔗 **Connections** | TradingView + MT5 login, risk management settings (max drawdown, lot size, daily targets) |

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React Native 0.74 |
| Build System | Expo SDK 51 + EAS Build |
| Navigation | React Navigation v6 (Bottom Tabs + Stack) |
| Charts | react-native-svg (custom candlestick renderer) |
| AI Engine | Anthropic Claude API (`claude-sonnet-4-20250514`) |
| Animations | React Native Animated + Expo Haptics |

---

## Project Structure

```
aegis-trade-apk/
├── App.js                          # Root entry — navigation setup
├── app.json                        # Expo config (name, icons, permissions)
├── eas.json                        # EAS Build profiles (preview APK / production)
├── package.json                    # Dependencies
├── babel.config.js
├── assets/
│   ├── icon.png                    # App icon (512×512)
│   ├── adaptive-icon.png           # Android adaptive icon
│   └── splash.png                  # Splash screen
└── src/
    ├── utils/
    │   └── theme.js                # Colours, fonts, shared data, callClaude()
    └── screens/
        ├── DashboardScreen.js      # Main dashboard
        ├── GoldScalperScreen.js    # Gold scalping module ← main feature
        ├── StrategyScreen.js       # Strategy lab + AI insights
        ├── HistoryScreen.js        # Trade history
        ├── AIChatScreen.js         # AI chat assistant
        └── ConnectionsScreen.js   # TradingView + MT5 connections
```

---

## Build the APK

### Prerequisites

- **Node.js 18+** — https://nodejs.org
- **Expo account (free)** — https://expo.dev
- **EAS CLI** — installed in Step 1 below

> ✅ No Android Studio, no Java SDK, no local build environment needed.
> Expo builds the APK in the cloud.

---

### Step 1 — Install dependencies

```bash
cd aegis-trade-apk
npm install
npm install -g eas-cli
```

---

### Step 2 — Log in to Expo

```bash
eas login
```

Enter your **expo.dev** email and password. Create a free account at https://expo.dev if you don't have one.

---

### Step 3 — Initialise the EAS project

```bash
eas init
```

This links your local project to your Expo account and writes a `projectId` into `app.json` automatically.

---

### Step 4 — Build the APK

**Preview APK** (fastest, ~5 min, for testing & sideloading):
```bash
eas build --platform android --profile preview
```

**Production APK** (optimised, for distribution):
```bash
eas build --platform android --profile production
```

When the build completes, Expo will give you a **download link** for the `.apk` file.

---

### Step 5 — Install on Android

**Option A — ADB (USB)**
```bash
adb install aegis-trade.apk
```

**Option B — Direct file transfer**
1. Copy the `.apk` to your Android phone
2. Go to **Settings → Security → Install Unknown Apps**
3. Enable installs from your file manager
4. Open the `.apk` and tap **Install**

---

## Configuration

### App Icon
Replace these files with your own **512×512 PNG** icon:
- `assets/icon.png` — standard icon
- `assets/adaptive-icon.png` — Android adaptive icon (foreground layer)

Use **https://icon.kitchen** to generate all required sizes.

### App Name & Bundle ID
Edit `app.json`:
```json
{
  "expo": {
    "name": "Aegis-Trade",
    "android": {
      "package": "com.aegistrade.app"
    }
  }
}
```

### Splash Screen Colour
Edit `app.json`:
```json
"splash": {
  "backgroundColor": "#080c10"
}
```

---

## API Key Security

> ⚠️ **Never ship your Anthropic API key inside a mobile app.**

For production, create a lightweight backend proxy:

```
User's Phone → POST https://your-server.com/api/claude → Anthropic API
```

**Example Express proxy (Node.js):**
```js
app.post('/api/claude', authenticateUser, async (req, res) => {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY,   // server-side only
    },
    body: JSON.stringify(req.body),
  });
  res.json(await response.json());
});
```

Then update `callClaude()` in `src/utils/theme.js` to point to your proxy URL.

---

## Screenshots

> The app uses a dark terminal-aesthetic theme with gold accents for the Gold Scalper module.

| Dashboard | Gold Scalper | AI Chat |
|---|---|---|
| Live charts + positions | XAUUSD M5 + AI signals | Claude trading assistant |

---

## Disclaimer

> This software is for **educational purposes only**.
> It is not financial advice. Trading involves significant risk of capital loss.
> Always thoroughly test any strategy before deploying with real funds.
> Past performance does not guarantee future results.

---

## License

MIT License · © 2025 Aegis-Trade
