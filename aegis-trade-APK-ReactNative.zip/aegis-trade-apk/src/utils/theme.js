// src/utils/theme.js
export const COLORS = {
  bg:       '#080c10',
  bg2:      '#0d1117',
  bg3:      '#111720',
  surface:  '#141b26',
  surface2: '#1a2333',
  border:   '#1e2d42',
  border2:  '#253650',
  accent:   '#00d4aa',
  accent2:  '#0099ff',
  accent3:  '#ff6b35',
  accent4:  '#9b59ff',
  danger:   '#ff4560',
  gold:     '#ffd700',
  goldDark: '#b8860b',
  text:     '#e8f0fe',
  text2:    '#8899aa',
  text3:    '#4d6070',
};

export const FONTS = {
  // React Native uses system fonts; these map to bold/mono variants
  head:    'System',
  mono:    'Courier',
  body:    'Courier',
};

export const SHADOWS = {
  glow: {
    shadowColor: '#00d4aa',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 5,
  },
  goldGlow: {
    shadowColor: '#ffd700',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 6,
  },
  card: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
};

export const MOCK_SYMBOLS = ['EURUSD','GBPUSD','XAUUSD','BTCUSD','NASDAQ','SPX500','USDJPY','AUDUSD'];

export const MOCK_TRADES = [
  { id:1, symbol:'EURUSD', type:'BUY',  entry:1.0842, current:1.0871, sl:1.0810, tp:1.0900, lots:0.5,  pnl:+14.5,  time:'09:42' },
  { id:2, symbol:'XAUUSD', type:'SELL', entry:2341.50,current:2328.20,sl:2360.0, tp:2300.0, lots:0.1,  pnl:+133.0, time:'10:15' },
  { id:3, symbol:'GBPUSD', type:'BUY',  entry:1.2680, current:1.2695, sl:1.2640, tp:1.2750, lots:0.3,  pnl:+4.5,   time:'11:02' },
  { id:4, symbol:'BTCUSD', type:'BUY',  entry:67250,  current:68100,  sl:65000,  tp:72000,  lots:0.01, pnl:+85.0,  time:'08:30' },
];

export const SCALP_SETUPS = [
  { id:1, name:'London Breakout',   tf:'M5', winRate:72, avgPips:8,  risk:'Low',    desc:'Trade the first 30-min London range break with volume confirmation.' },
  { id:2, name:'NY Kill Zone',      tf:'M1', winRate:68, avgPips:5,  risk:'Medium', desc:'Scalp reversals at NY open when gold reacts to USD data.' },
  { id:3, name:'EMA Ribbon Surf',   tf:'M5', winRate:65, avgPips:7,  risk:'Low',    desc:'Trade with the ribbon of EMA 8/13/21 on pullbacks during trend.' },
  { id:4, name:'Spike & Fade',      tf:'M1', winRate:58, avgPips:10, risk:'High',   desc:'Fade sharp impulsive spikes on M1 when RSI hits extreme levels.' },
  { id:5, name:'Support Bounce',    tf:'M5', winRate:70, avgPips:6,  risk:'Low',    desc:'Buy at key intraday support zones during bullish sessions.' },
];

export const callClaude = async (messages, systemPrompt) => {
  const resp = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      system: systemPrompt,
      messages,
    }),
  });
  const data = await resp.json();
  return data.content?.map(b => b.text || '').join('') || 'No response.';
};

export const generatePriceSeries = (base, len = 60) => {
  const arr = [base];
  for (let i = 1; i < len; i++) {
    const change = (Math.random() - 0.49) * base * 0.003;
    arr.push(Math.max(base * 0.95, arr[i - 1] + change));
  }
  return arr;
};
