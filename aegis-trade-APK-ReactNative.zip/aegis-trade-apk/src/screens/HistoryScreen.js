// src/screens/HistoryScreen.js
import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import { COLORS } from '../utils/theme';

const HIST = [
  { id:10, symbol:'EURUSD', type:'BUY',  entry:1.0780, exit:1.0842, pnl:+31.0, pnlPct:+0.57, date:'Mar 19' },
  { id:11, symbol:'NASDAQ', type:'SELL', entry:18420,  exit:18210,  pnl:+210.0,pnlPct:+1.14, date:'Mar 19' },
  { id:12, symbol:'XAUUSD', type:'BUY',  entry:2298.0, exit:2340.0, pnl:+420.0,pnlPct:+1.83, date:'Mar 18' },
  { id:13, symbol:'GBPUSD', type:'SELL', entry:1.2710, exit:1.2760, pnl:-15.0, pnlPct:-0.39, date:'Mar 18' },
  { id:14, symbol:'USDJPY', type:'BUY',  entry:149.80, exit:150.40, pnl:+60.0, pnlPct:+0.40, date:'Mar 17' },
  { id:15, symbol:'BTCUSD', type:'BUY',  entry:65100,  exit:67250,  pnl:+215.0,pnlPct:+3.30, date:'Mar 17' },
];

const STATS = [
  ['Total Trades','21'],['Winners','15 (71.4%)'],['Total P&L','+$1,156'],
  ['Best Trade','+$420 XAUUSD'],['Avg Win','+$77'],['Avg Loss','-$12'],
];

export default function HistoryScreen() {
  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom:30 }}>
      <View style={styles.header}><Text style={styles.headerText}>Trade History</Text></View>

      <View style={styles.statsGrid}>
        {STATS.map(([l,v]) => (
          <View key={l} style={styles.statCard}>
            <Text style={styles.statLabel}>{l}</Text>
            <Text style={[styles.statVal, { color: v.startsWith('+') ? COLORS.accent : v.startsWith('-') ? COLORS.danger : COLORS.text }]}>{v}</Text>
          </View>
        ))}
      </View>

      <View style={{ padding:16 }}>
        <Text style={styles.sectionTitle}>Closed Trades</Text>
        {HIST.map(t => (
          <View key={t.id} style={styles.row}>
            <View style={{ flex:1 }}>
              <View style={{ flexDirection:'row', gap:8, alignItems:'center', marginBottom:3 }}>
                <Text style={{ fontFamily:'Courier', fontWeight:'bold', fontSize:12, color:COLORS.text }}>{t.symbol}</Text>
                <View style={[styles.badge, { borderColor: t.type==='BUY'?COLORS.accent:COLORS.danger }]}>
                  <Text style={{ fontSize:8, color: t.type==='BUY'?COLORS.accent:COLORS.danger, fontFamily:'Courier' }}>{t.type}</Text>
                </View>
                <Text style={{ fontSize:9, color:COLORS.text3, fontFamily:'Courier' }}>{t.date}</Text>
              </View>
              <Text style={{ fontSize:10, color:COLORS.text2, fontFamily:'Courier' }}>{t.entry} → {t.exit}</Text>
            </View>
            <View style={{ alignItems:'flex-end' }}>
              <Text style={{ fontSize:14, fontFamily:'Courier', fontWeight:'900', color: t.pnl>0?COLORS.accent:COLORS.danger }}>{t.pnl>0?'+':''}${t.pnl.toFixed(2)}</Text>
              <Text style={{ fontSize:9, color: t.pnlPct>0?COLORS.accent:COLORS.danger, fontFamily:'Courier' }}>{t.pnlPct>0?'+':''}{t.pnlPct}%</Text>
            </View>
          </View>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:    { flex:1, backgroundColor:COLORS.bg },
  header:       { padding:16, paddingTop:50, borderBottomWidth:1, borderBottomColor:COLORS.border },
  headerText:   { fontSize:18, fontFamily:'Courier', fontWeight:'900', color:COLORS.text },
  statsGrid:    { flexDirection:'row', flexWrap:'wrap', gap:8, padding:16 },
  statCard:     { flex:1, minWidth:'46%', backgroundColor:COLORS.surface, borderRadius:8, padding:10, borderWidth:1, borderColor:COLORS.border },
  statLabel:    { fontSize:8, color:COLORS.text3, fontFamily:'Courier', textTransform:'uppercase' },
  statVal:      { fontSize:13, fontFamily:'Courier', fontWeight:'bold', marginTop:2 },
  sectionTitle: { fontSize:10, color:COLORS.text2, fontFamily:'Courier', textTransform:'uppercase', letterSpacing:0.5, marginBottom:10, fontWeight:'bold' },
  row:          { flexDirection:'row', alignItems:'center', backgroundColor:COLORS.surface, borderRadius:8, padding:12, marginBottom:8, borderWidth:1, borderColor:COLORS.border },
  badge:        { paddingHorizontal:6, paddingVertical:2, borderRadius:4, borderWidth:1 },
});
