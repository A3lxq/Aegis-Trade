// src/screens/GoldScalperScreen.js
import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, ScrollView, TouchableOpacity, TextInput,
  StyleSheet, Dimensions, Animated, ActivityIndicator, Alert,
} from 'react-native';
import Svg, { Rect, Line, Path, Text as SvgText, Circle, Polyline, Defs, LinearGradient, Stop } from 'react-native-svg';
import { LinearGradient as ExpoGradient } from 'expo-linear-gradient';
import { COLORS, SHADOWS, SCALP_SETUPS, callClaude } from '../utils/theme';

const { width: SW } = Dimensions.get('window');

// ── Helpers ──────────────────────────────────────────────────────────────────
const ema = (arr, period) => {
  const k = 2 / (period + 1);
  const res = [arr[0]];
  for (let i = 1; i < arr.length; i++) res.push(arr[i] * k + res[i - 1] * (1 - k));
  return res;
};

const genCandles = (base, n = 50) => Array.from({ length: n }, (_, i) => {
  const o = base + (Math.random() - 0.5) * 6;
  const c = o + (Math.random() - 0.48) * 4;
  return { o, c, h: Math.max(o, c) + Math.random() * 2, l: Math.min(o, c) - Math.random() * 1.5, t: i };
});

// ── Candlestick Chart ─────────────────────────────────────────────────────
function GoldCandleChart({ candles }) {
  const W = SW - 40, H = 160;
  const all = candles.flatMap(c => [c.h, c.l]);
  const min = Math.min(...all) - 0.5;
  const max = Math.max(...all) + 0.5;
  const range = max - min || 1;
  const toY  = v => H - ((v - min) / range) * (H - 24) - 12;
  const cw   = W / candles.length;

  const closes = candles.map(c => c.c);
  const ema8  = ema(closes, 8);
  const ema21 = ema(closes, 21);
  const toPath = arr => arr.map((v, i) => `${i === 0 ? 'M' : 'L'}${i * cw + cw / 2},${toY(v)}`).join(' ');

  return (
    <View style={{ backgroundColor: COLORS.bg2, borderRadius: 10, overflow: 'hidden' }}>
      <Svg width={W} height={H}>
        <Defs>
          <LinearGradient id="goldGrad" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%" stopColor={COLORS.gold} stopOpacity="0.15" />
            <Stop offset="100%" stopColor={COLORS.gold} stopOpacity="0" />
          </LinearGradient>
        </Defs>
        {[0,1,2,3].map(i => (
          <Line key={i} x1="0" y1={12 + i * (H - 24) / 3} x2={W} y2={12 + i * (H - 24) / 3}
            stroke={COLORS.border} strokeWidth="0.5" />
        ))}
        {candles.map((c, i) => {
          const x  = i * cw + cw * 0.15;
          const bw = cw * 0.7;
          const up = c.c >= c.o;
          const col = up ? COLORS.accent : COLORS.danger;
          const bTop = toY(Math.max(c.o, c.c));
          const bH   = Math.abs(toY(c.o) - toY(c.c)) || 1;
          return (
            <React.Fragment key={i}>
              <Line x1={x + bw / 2} y1={toY(c.h)} x2={x + bw / 2} y2={toY(c.l)} stroke={col} strokeWidth="0.8" />
              <Rect x={x} y={bTop} width={bw} height={bH} fill={col} opacity={0.85} />
            </React.Fragment>
          );
        })}
        <Path d={toPath(ema8)}  fill="none" stroke={COLORS.gold}   strokeWidth="1.2" opacity="0.9" />
        <Path d={toPath(ema21)} fill="none" stroke={COLORS.accent2} strokeWidth="1.2" opacity="0.8" />
        {[0,1,2,3].map(i => {
          const v = min + (range * (3 - i) / 3);
          return <SvgText key={i} x={W - 2} y={16 + i * (H - 24) / 3} fill={COLORS.text3} fontSize="8" textAnchor="end">{v.toFixed(1)}</SvgText>;
        })}
      </Svg>
      <View style={{ flexDirection: 'row', gap: 12, padding: 6, paddingTop: 0 }}>
        {[['EMA 8', COLORS.gold], ['EMA 21', COLORS.accent2]].map(([l, c]) => (
          <View key={l} style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <View style={{ width: 12, height: 2, backgroundColor: c, borderRadius: 1 }} />
            <Text style={{ fontSize: 9, color: COLORS.text3, fontFamily: 'Courier' }}>{l}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

// ── Live Price Header ──────────────────────────────────────────────────────
function GoldPriceHeader() {
  const [price, setPrice]   = useState(2341.50);
  const [change, setChange] = useState(+3.20);
  const [bid, setBid]       = useState(2341.30);
  const [ask, setAsk]       = useState(2341.70);
  const pulseAnim           = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const iv = setInterval(() => {
      const delta = (Math.random() - 0.49) * 0.8;
      setPrice(p  => { const n = parseFloat((p + delta).toFixed(2)); setBid(parseFloat((n - 0.20).toFixed(2))); setAsk(parseFloat((n + 0.20).toFixed(2))); return n; });
      setChange(c => parseFloat((c + delta * 0.4).toFixed(2)));
    }, 700);
    Animated.loop(Animated.sequence([
      Animated.timing(pulseAnim, { toValue: 1.04, duration: 600, useNativeDriver: true }),
      Animated.timing(pulseAnim, { toValue: 1.00, duration: 600, useNativeDriver: true }),
    ])).start();
    return () => clearInterval(iv);
  }, []);

  const up = change >= 0;
  return (
    <ExpoGradient colors={['#1a1200', '#0d1117']} style={styles.goldHeader}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
        <Animated.Text style={{ fontSize: 28, transform: [{ scale: pulseAnim }] }}>🥇</Animated.Text>
        <View>
          <Text style={styles.goldTitle}>XAUUSD · GOLD SCALPER</Text>
          <Text style={[styles.goldPrice, { color: up ? COLORS.accent : COLORS.danger }]}>{price.toFixed(2)}</Text>
          <Text style={{ fontSize: 11, color: up ? COLORS.accent : COLORS.danger, fontFamily: 'Courier' }}>
            {up ? '▲' : '▼'} {Math.abs(change).toFixed(2)} ({up ? '+' : ''}{(change / (price - change) * 100).toFixed(2)}%)
          </Text>
        </View>
        <View style={{ marginLeft: 'auto', gap: 4 }}>
          <Text style={styles.bidAsk}>BID: <Text style={{ color: COLORS.danger }}>{bid.toFixed(2)}</Text></Text>
          <Text style={styles.bidAsk}>ASK: <Text style={{ color: COLORS.accent }}>{ask.toFixed(2)}</Text></Text>
          <Text style={styles.bidAsk}>SPREAD: <Text style={{ color: COLORS.text2 }}>0.40</Text></Text>
        </View>
      </View>
    </ExpoGradient>
  );
}

// ── Main Screen ────────────────────────────────────────────────────────────
export default function GoldScalperScreen({ mt5Connected }) {
  const [candles, setCandles]           = useState(() => genCandles(2341, 50));
  const [tab, setTab]                   = useState('trade');
  const [autoScalp, setAutoScalp]       = useState(false);
  const [lotSize, setLotSize]           = useState('0.10');
  const [slPips, setSlPips]             = useState('8');
  const [tpPips, setTpPips]             = useState('12');
  const [aiSignal, setAiSignal]         = useState(null);
  const [loadingSignal, setLoadingSignal] = useState(false);
  const [activeSetup, setActiveSetup]   = useState(SCALP_SETUPS[0]);
  const [openTrades, setOpenTrades]     = useState([
    { id:1, type:'BUY',  entry:2339.80, current:2341.50, sl:2331.80, tp:2351.80, lots:0.10, pnl:+17.0, time:'09:42' },
    { id:2, type:'SELL', entry:2344.20, current:2341.50, sl:2352.20, tp:2332.20, lots:0.05, pnl:+13.5, time:'10:05' },
  ]);
  const [history, setHistory]           = useState([
    { id:10, type:'BUY',  entry:2337.10, exit:2343.50, pips:'+6.4', pnl:+64.0, time:'08:31' },
    { id:11, type:'SELL', entry:2348.80, exit:2342.10, pips:'+6.7', pnl:+33.5, time:'08:47' },
    { id:12, type:'BUY',  entry:2340.20, exit:2338.00, pips:'-2.2', pnl:-22.0, time:'09:15' },
    { id:13, type:'BUY',  entry:2335.50, exit:2343.20, pips:'+7.7', pnl:+77.0, time:'09:28' },
  ]);

  // Update candles & trade PnL live
  useEffect(() => {
    const iv = setInterval(() => {
      setCandles(prev => {
        const last = prev[prev.length - 1];
        const o = last.c;
        const c = o + (Math.random() - 0.49) * 2.5;
        return [...prev.slice(-49), { o, c, h: Math.max(o,c)+Math.random()*1.2, l: Math.min(o,c)-Math.random()*1.0, t: last.t+1 }];
      });
      setOpenTrades(prev => prev.map(t => {
        const d = (Math.random() - 0.48) * 0.5;
        const cur = parseFloat((t.current + d).toFixed(2));
        const pip = t.type === 'BUY' ? cur - t.entry : t.entry - cur;
        return { ...t, current: cur, pnl: parseFloat((pip * t.lots * 100).toFixed(2)) };
      }));
    }, 900);
    return () => clearInterval(iv);
  }, []);

  const getAiSignal = async () => {
    setLoadingSignal(true);
    setAiSignal(null);
    try {
      const result = await callClaude(
        [{ role: 'user', content: `Generate a XAUUSD scalp signal near $2341. Return ONLY JSON: { direction:"BUY"or"SELL", entry:number, sl:number, tp:number, tp2:number, confidence:number, sessionRating:string, reasoning:string, setupType:string, riskReward:string }` }],
        'You are a professional gold scalping trader. Return ONLY valid JSON near price 2341, no markdown.'
      );
      const clean = result.replace(/```json|```/g, '').trim();
      setAiSignal(JSON.parse(clean));
    } catch {
      setAiSignal({ direction:'BUY', entry:2341.50, sl:2333.50, tp:2349.50, tp2:2355.00, confidence:72, sessionRating:'Good', reasoning:'EMA 8 crossed above EMA 21 on M5. RSI at 48 heading up from pullback zone.', setupType:'EMA Pullback', riskReward:'1:1.5' });
    }
    setLoadingSignal(false);
  };

  const placeOrder = (type) => {
    const entry = parseFloat((2341.50 + (Math.random()-0.5)*0.4).toFixed(2));
    const sl = parseFloat((type==='BUY' ? entry-parseFloat(slPips) : entry+parseFloat(slPips)).toFixed(2));
    const tp = parseFloat((type==='BUY' ? entry+parseFloat(tpPips) : entry-parseFloat(tpPips)).toFixed(2));
    setOpenTrades(p => [...p, { id:Date.now(), type, entry, current:entry, sl, tp, lots:parseFloat(lotSize||0.01), pnl:0, time:new Date().toTimeString().slice(0,5) }]);
    Alert.alert('Order Placed ✓', `${type} GOLD @ ${entry}\nSL: ${sl} | TP: ${tp}`, [{ text:'OK' }]);
  };

  const closeTrade = (id) => {
    const t = openTrades.find(x => x.id === id);
    if (!t) return;
    const pips = t.type==='BUY' ? (t.current-t.entry).toFixed(1) : (t.entry-t.current).toFixed(1);
    setHistory(prev => [{ id:Date.now(), type:t.type, entry:t.entry, exit:t.current, pips:`${parseFloat(pips)>=0?'+':''}${pips}`, pnl:t.pnl, time:new Date().toTimeString().slice(0,5) }, ...prev.slice(0,9)]);
    setOpenTrades(prev => prev.filter(x => x.id !== id));
  };

  const dayPnl   = history.reduce((s,t) => s+t.pnl, 0) + openTrades.reduce((s,t) => s+t.pnl, 0);
  const winRate  = history.length > 0 ? ((history.filter(t=>t.pnl>0).length / history.length)*100).toFixed(0) : 0;
  const rr       = (parseFloat(tpPips||1)/parseFloat(slPips||1)).toFixed(1);
  const riskAmt  = (parseFloat(lotSize||0)*parseFloat(slPips||0)*10).toFixed(2);
  const rewardAmt= (parseFloat(lotSize||0)*parseFloat(tpPips||0)*10).toFixed(2);

  const SESSIONS = [
    { name:'Asian',   vol:'Low',      color:COLORS.accent4 },
    { name:'London',  vol:'High',     color:COLORS.accent2 },
    { name:'NY Open', vol:'V.High',   color:COLORS.accent  },
    { name:'Overlap', vol:'Extreme',  color:COLORS.accent3 },
  ];

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 20 }}>

        {/* Gold Header */}
        <GoldPriceHeader />

        {/* Stats row */}
        <View style={styles.statsRow}>
          {[
            ['Day P&L', `${dayPnl>=0?'+':''}$${dayPnl.toFixed(2)}`, dayPnl>=0?COLORS.accent:COLORS.danger],
            ['Win Rate', `${winRate}%`, parseInt(winRate)>=60?COLORS.accent:COLORS.accent3],
            ['Open',  `${openTrades.length}`,  COLORS.text2],
            ['Closed',`${history.length}`,     COLORS.text2],
          ].map(([l,v,c]) => (
            <View key={l} style={[styles.statCard, SHADOWS.card]}>
              <Text style={styles.statLabel}>{l}</Text>
              <Text style={[styles.statValue, { color: c }]}>{v}</Text>
            </View>
          ))}
        </View>

        {/* Sessions */}
        <View style={styles.sessionsRow}>
          {SESSIONS.map(s => (
            <View key={s.name} style={[styles.sessionBadge, { borderColor: s.color + '50' }]}>
              <Text style={[styles.sessionName, { color: s.color }]}>{s.name}</Text>
              <Text style={[styles.sessionVol, { color: s.color }]}>{s.vol}</Text>
            </View>
          ))}
        </View>

        {/* Chart */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: COLORS.gold }]}>M5 Candlestick Chart</Text>
            <View style={styles.row}>
              <View style={[styles.dot, { backgroundColor: autoScalp ? COLORS.accent : COLORS.danger }]} />
              <TouchableOpacity onPress={() => setAutoScalp(v => !v)} style={[styles.toggleBtn, { borderColor: autoScalp ? COLORS.accent : COLORS.border }]}>
                <Text style={{ fontSize: 9, color: autoScalp ? COLORS.accent : COLORS.text2, fontFamily:'Courier' }}>
                  {autoScalp ? 'AUTO ON' : 'AUTO OFF'}
                </Text>
              </TouchableOpacity>
            </View>
          </View>
          <GoldCandleChart candles={candles} />
        </View>

        {/* Indicator pills */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ paddingLeft: 16, marginBottom: 12 }}>
          {[['RSI','48','Neutral',COLORS.text2],['MACD','▲ Bull','Cross',COLORS.accent],['EMA','8>21','Bullish',COLORS.accent],['ATR','2.84','Vol',COLORS.accent3],['Vol','+28%','High',COLORS.accent2]].map(([l,v,s,c]) => (
            <View key={l} style={styles.indicatorPill}>
              <Text style={{ fontSize: 8, color: COLORS.text3, fontFamily:'Courier' }}>{l}</Text>
              <Text style={{ fontSize: 11, color: c, fontFamily:'Courier', fontWeight:'bold' }}>{v}</Text>
              <Text style={{ fontSize: 8, color: COLORS.text3, fontFamily:'Courier' }}>{s}</Text>
            </View>
          ))}
        </ScrollView>

        {/* AI Signal */}
        <View style={[styles.section, styles.goldBorderCard]}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: COLORS.gold }]}>⚡ AI Scalp Signal</Text>
            <Text style={{ fontSize: 9, color: COLORS.text3, fontFamily:'Courier' }}>Claude AI</Text>
          </View>
          <TouchableOpacity onPress={getAiSignal} disabled={loadingSignal}
            style={[styles.goldBtn, loadingSignal && { opacity: 0.7 }]}>
            {loadingSignal
              ? <><ActivityIndicator size="small" color="#000" /><Text style={styles.goldBtnText}>  Analyzing Gold...</Text></>
              : <Text style={styles.goldBtnText}>🥇  GET GOLD SCALP SIGNAL</Text>
            }
          </TouchableOpacity>

          {aiSignal && !loadingSignal && (
            <View style={{ marginTop: 12, gap: 10 }}>
              <View style={[styles.directionBanner, { backgroundColor: aiSignal.direction==='BUY' ? 'rgba(0,212,170,0.12)' : 'rgba(255,69,96,0.12)', borderColor: aiSignal.direction==='BUY' ? COLORS.accent+'50' : COLORS.danger+'50' }]}>
                <Text style={{ fontSize: 24, fontWeight:'900', color: aiSignal.direction==='BUY'?COLORS.accent:COLORS.danger }}>{aiSignal.direction==='BUY'?'▲ BUY':'▼ SELL'}</Text>
                <View>
                  <Text style={{ fontSize: 9, color: COLORS.text3, fontFamily:'Courier' }}>SETUP</Text>
                  <Text style={{ fontSize: 11, color: COLORS.text, fontFamily:'Courier' }}>{aiSignal.setupType}</Text>
                </View>
                <View style={{ marginLeft:'auto' }}>
                  <Text style={{ fontSize: 9, color: COLORS.text3, fontFamily:'Courier' }}>SESSION</Text>
                  <Text style={{ fontSize: 11, color: COLORS.accent, fontFamily:'Courier' }}>{aiSignal.sessionRating}</Text>
                </View>
              </View>

              <View style={styles.priceGrid}>
                {[['Entry',aiSignal.entry,COLORS.text],['Stop Loss',aiSignal.sl,COLORS.danger],['TP 1',aiSignal.tp,COLORS.accent],['TP 2',aiSignal.tp2,COLORS.gold]].map(([l,v,c]) => (
                  <View key={l} style={styles.priceBox}>
                    <Text style={{ fontSize: 8, color: COLORS.text3, fontFamily:'Courier' }}>{l.toUpperCase()}</Text>
                    <Text style={{ fontSize: 14, color: c, fontFamily:'Courier', fontWeight:'bold' }}>{typeof v==='number'?v.toFixed(2):v}</Text>
                  </View>
                ))}
              </View>

              <View>
                <View style={styles.confRow}>
                  <Text style={{ fontSize: 9, color: COLORS.text3, fontFamily:'Courier' }}>CONFIDENCE</Text>
                  <Text style={{ fontSize: 9, color: COLORS.accent, fontFamily:'Courier' }}>{aiSignal.confidence}%</Text>
                </View>
                <View style={styles.progressBg}><View style={[styles.progressFill, { width: `${aiSignal.confidence}%`, backgroundColor: aiSignal.confidence>70?COLORS.accent:COLORS.gold }]} /></View>
              </View>

              <View style={{ backgroundColor: COLORS.bg2, borderRadius: 8, padding: 10 }}>
                <Text style={{ fontSize: 11, color: COLORS.text2, fontFamily:'Courier', lineHeight: 17 }}>{aiSignal.reasoning}</Text>
              </View>

              <TouchableOpacity onPress={() => placeOrder(aiSignal.direction)}
                style={[styles.executeBtn, { borderColor: aiSignal.direction==='BUY'?COLORS.accent:COLORS.danger, backgroundColor: aiSignal.direction==='BUY'?'rgba(0,212,170,0.12)':'rgba(255,69,96,0.12)' }]}>
                <Text style={{ color: aiSignal.direction==='BUY'?COLORS.accent:COLORS.danger, fontFamily:'Courier', fontWeight:'bold', fontSize: 12 }}>
                  ▶  EXECUTE IN MT5
                </Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* Tab bar */}
        <View style={styles.tabBar}>
          {[['trade','Quick Trade'],['setups','Setups'],['history','History']].map(([t,l]) => (
            <TouchableOpacity key={t} onPress={() => setTab(t)} style={[styles.tabBtn, tab===t && { borderBottomColor: COLORS.gold, borderBottomWidth: 2 }]}>
              <Text style={{ fontSize: 10, fontFamily:'Courier', color: tab===t?COLORS.gold:COLORS.text2, textTransform:'uppercase', letterSpacing: 0.5 }}>{l}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {tab === 'trade' && (
          <View style={[styles.section, { marginTop: 0 }]}>
            <View style={styles.inputGrid}>
              {[['Lot Size', lotSize, setLotSize], ['SL (pips)', slPips, setSlPips], ['TP (pips)', tpPips, setTpPips]].map(([l,v,s]) => (
                <View key={l} style={{ flex: 1 }}>
                  <Text style={styles.inputLabel}>{l}</Text>
                  <TextInput style={styles.input} value={v} onChangeText={s} keyboardType="numeric" />
                </View>
              ))}
            </View>
            <Text style={{ fontSize: 9, color: COLORS.text3, fontFamily:'Courier', textAlign:'center', marginBottom: 10 }}>
              Risk: ${riskAmt} · Reward: ${rewardAmt} · RR 1:{rr}
            </Text>
            <View style={{ flexDirection:'row', gap: 10 }}>
              <TouchableOpacity onPress={() => placeOrder('BUY')} style={[styles.orderBtn, styles.buyBtn]}>
                <Text style={styles.buyBtnText}>▲  BUY GOLD</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => placeOrder('SELL')} style={[styles.orderBtn, styles.sellBtn]}>
                <Text style={styles.sellBtnText}>▼  SELL GOLD</Text>
              </TouchableOpacity>
            </View>

            {/* Open trades */}
            {openTrades.length > 0 && (
              <View style={{ marginTop: 14 }}>
                <Text style={[styles.sectionTitle, { marginBottom: 8 }]}>Open Trades ({openTrades.length})</Text>
                {openTrades.map(t => {
                  const range   = Math.abs(t.tp - t.entry);
                  const progress = t.type==='BUY' ? Math.max(0,Math.min(100,((t.current-t.entry)/range)*100)) : Math.max(0,Math.min(100,((t.entry-t.current)/range)*100));
                  return (
                    <View key={t.id} style={styles.tradeCard}>
                      <View style={styles.tradeRow}>
                        <View style={[styles.badge, { backgroundColor: t.type==='BUY'?COLORS.accent+'20':COLORS.danger+'20', borderColor: t.type==='BUY'?COLORS.accent:COLORS.danger }]}>
                          <Text style={{ color: t.type==='BUY'?COLORS.accent:COLORS.danger, fontSize: 9, fontFamily:'Courier', fontWeight:'bold' }}>{t.type}</Text>
                        </View>
                        <Text style={{ fontSize: 10, color: COLORS.text2, fontFamily:'Courier' }}>{t.entry.toFixed(2)} → {t.current.toFixed(2)}</Text>
                        <Text style={{ marginLeft:'auto', fontSize: 12, fontFamily:'Courier', fontWeight:'bold', color: t.pnl>=0?COLORS.accent:COLORS.danger }}>
                          {t.pnl>=0?'+':''}${t.pnl.toFixed(2)}
                        </Text>
                      </View>
                      <View style={{ flexDirection:'row', gap:10, marginTop:4, marginBottom:6 }}>
                        <Text style={{ fontSize:8, color:COLORS.text3, fontFamily:'Courier' }}>SL: <Text style={{ color:COLORS.danger }}>{t.sl.toFixed(2)}</Text></Text>
                        <Text style={{ fontSize:8, color:COLORS.text3, fontFamily:'Courier' }}>TP: <Text style={{ color:COLORS.accent }}>{t.tp.toFixed(2)}</Text></Text>
                        <Text style={{ fontSize:8, color:COLORS.text3, fontFamily:'Courier' }}>Lots: {t.lots}</Text>
                      </View>
                      <View style={styles.progressBg}><View style={[styles.progressFill, { width:`${progress}%`, backgroundColor:progress>0?COLORS.accent:COLORS.danger }]} /></View>
                      <TouchableOpacity onPress={() => closeTrade(t.id)} style={styles.closeBtn}>
                        <Text style={{ fontSize:9, color:COLORS.danger, fontFamily:'Courier' }}>CLOSE TRADE</Text>
                      </TouchableOpacity>
                    </View>
                  );
                })}
              </View>
            )}
          </View>
        )}

        {tab === 'setups' && (
          <View style={{ padding: 16, gap: 10 }}>
            {SCALP_SETUPS.map(s => (
              <TouchableOpacity key={s.id} onPress={() => setActiveSetup(s)}
                style={[styles.setupCard, activeSetup.id===s.id && { borderColor: COLORS.gold+'50', backgroundColor: COLORS.gold+'08' }]}>
                <View style={{ flexDirection:'row', alignItems:'center', gap:10 }}>
                  <View style={{ flex:1 }}>
                    <View style={{ flexDirection:'row', gap:6, alignItems:'center', marginBottom:4 }}>
                      <Text style={{ fontFamily:'Courier', fontWeight:'bold', fontSize:13, color:COLORS.text }}>{s.name}</Text>
                      <View style={[styles.badge, { borderColor:COLORS.accent2+'60' }]}><Text style={{ fontSize:8, color:COLORS.accent2, fontFamily:'Courier' }}>{s.tf}</Text></View>
                    </View>
                    <Text style={{ fontSize:11, color:COLORS.text2, fontFamily:'Courier', lineHeight:16 }}>{s.desc}</Text>
                  </View>
                  <View style={{ alignItems:'center' }}>
                    <Text style={{ fontSize:9, color:COLORS.text3, fontFamily:'Courier' }}>WIN</Text>
                    <Text style={{ fontSize:20, fontWeight:'900', color:s.winRate>=68?COLORS.accent:COLORS.accent3 }}>{s.winRate}%</Text>
                    <Text style={{ fontSize:8, color:COLORS.text3, fontFamily:'Courier' }}>+{s.avgPips}p avg</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {tab === 'history' && (
          <View style={{ padding: 16, gap: 8 }}>
            {history.map(t => (
              <View key={t.id} style={styles.historyRow}>
                <View style={[styles.badge, { borderColor: t.type==='BUY'?COLORS.accent:COLORS.danger }]}>
                  <Text style={{ fontSize:8, color: t.type==='BUY'?COLORS.accent:COLORS.danger, fontFamily:'Courier' }}>{t.type}</Text>
                </View>
                <Text style={{ fontSize:10, color:COLORS.text2, fontFamily:'Courier', flex:1 }}>{t.entry} → {t.exit}</Text>
                <Text style={{ fontSize:10, color:parseFloat(t.pips)>=0?COLORS.accent:COLORS.danger, fontFamily:'Courier' }}>{t.pips}p</Text>
                <Text style={{ fontSize:11, fontFamily:'Courier', fontWeight:'bold', color:t.pnl>=0?COLORS.accent:COLORS.danger, marginLeft:8 }}>
                  {t.pnl>=0?'+':''}${t.pnl.toFixed(2)}
                </Text>
              </View>
            ))}
          </View>
        )}

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container:      { flex:1, backgroundColor: COLORS.bg },
  goldHeader:     { padding:16, margin:16, borderRadius:12, borderWidth:1, borderColor:'rgba(255,215,0,0.2)' },
  goldTitle:      { fontSize:13, fontFamily:'Courier', fontWeight:'bold', color:COLORS.gold, letterSpacing:0.5, marginBottom:2 },
  goldPrice:      { fontSize:28, fontFamily:'Courier', fontWeight:'900', marginBottom:2 },
  bidAsk:         { fontSize:10, color:COLORS.text3, fontFamily:'Courier' },
  statsRow:       { flexDirection:'row', gap:8, paddingHorizontal:16, marginBottom:12 },
  statCard:       { flex:1, backgroundColor:COLORS.surface, borderRadius:8, padding:10, alignItems:'center', borderWidth:1, borderColor:COLORS.border },
  statLabel:      { fontSize:8, color:COLORS.text3, fontFamily:'Courier', textTransform:'uppercase' },
  statValue:      { fontSize:14, fontWeight:'900', fontFamily:'Courier', marginTop:2 },
  sessionsRow:    { flexDirection:'row', gap:6, paddingHorizontal:16, marginBottom:12 },
  sessionBadge:   { flex:1, backgroundColor:COLORS.surface, borderRadius:6, padding:8, borderWidth:1, alignItems:'center' },
  sessionName:    { fontSize:8, fontFamily:'Courier', fontWeight:'bold' },
  sessionVol:     { fontSize:7, fontFamily:'Courier', marginTop:1 },
  section:        { margin:16, marginTop:12 },
  sectionHeader:  { flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:8 },
  sectionTitle:   { fontSize:11, fontFamily:'Courier', fontWeight:'bold', color:COLORS.text2, textTransform:'uppercase', letterSpacing:0.5 },
  row:            { flexDirection:'row', alignItems:'center', gap:6 },
  dot:            { width:6, height:6, borderRadius:3 },
  toggleBtn:      { paddingHorizontal:8, paddingVertical:3, borderRadius:4, borderWidth:1 },
  indicatorPill:  { backgroundColor:COLORS.surface2, borderRadius:8, padding:8, marginRight:8, alignItems:'center', minWidth:60, borderWidth:1, borderColor:COLORS.border },
  goldBorderCard: { backgroundColor:COLORS.surface, borderRadius:12, borderWidth:1, borderColor:'rgba(255,215,0,0.2)', padding:14 },
  goldBtn:        { backgroundColor:COLORS.gold, borderRadius:8, padding:14, flexDirection:'row', alignItems:'center', justifyContent:'center' },
  goldBtnText:    { color:'#000', fontFamily:'Courier', fontWeight:'900', fontSize:13 },
  directionBanner:{ flexDirection:'row', alignItems:'center', gap:16, padding:12, borderRadius:10, borderWidth:1 },
  priceGrid:      { flexDirection:'row', flexWrap:'wrap', gap:8 },
  priceBox:       { flex:1, minWidth:'45%', backgroundColor:COLORS.bg2, borderRadius:8, padding:10 },
  confRow:        { flexDirection:'row', justifyContent:'space-between', marginBottom:4 },
  progressBg:     { height:4, backgroundColor:COLORS.border, borderRadius:2, overflow:'hidden', marginBottom:4 },
  progressFill:   { height:'100%', borderRadius:2 },
  executeBtn:     { borderWidth:1, borderRadius:8, padding:12, alignItems:'center' },
  tabBar:         { flexDirection:'row', borderBottomWidth:1, borderBottomColor:COLORS.border, marginHorizontal:16 },
  tabBtn:         { flex:1, paddingVertical:10, alignItems:'center', borderBottomWidth:2, borderBottomColor:'transparent' },
  inputGrid:      { flexDirection:'row', gap:8, marginBottom:8 },
  inputLabel:     { fontSize:9, color:COLORS.text3, fontFamily:'Courier', marginBottom:4 },
  input:          { backgroundColor:COLORS.bg2, borderWidth:1, borderColor:COLORS.border, borderRadius:6, padding:8, color:COLORS.text, fontFamily:'Courier', fontSize:12, textAlign:'center' },
  orderBtn:       { flex:1, padding:14, borderRadius:8, borderWidth:1, alignItems:'center', justifyContent:'center' },
  buyBtn:         { backgroundColor:'rgba(0,212,170,0.15)', borderColor:COLORS.accent },
  buyBtnText:     { color:COLORS.accent, fontFamily:'Courier', fontWeight:'bold', fontSize:13 },
  sellBtn:        { backgroundColor:'rgba(255,69,96,0.15)', borderColor:COLORS.danger },
  sellBtnText:    { color:COLORS.danger, fontFamily:'Courier', fontWeight:'bold', fontSize:13 },
  tradeCard:      { backgroundColor:COLORS.surface, borderRadius:8, padding:10, marginBottom:8, borderWidth:1, borderColor:COLORS.border },
  tradeRow:       { flexDirection:'row', alignItems:'center', gap:8 },
  badge:          { paddingHorizontal:6, paddingVertical:2, borderRadius:4, borderWidth:1, backgroundColor:'transparent' },
  closeBtn:       { marginTop:8, padding:6, borderRadius:4, borderWidth:1, borderColor:COLORS.danger, alignItems:'center' },
  setupCard:      { backgroundColor:COLORS.surface, borderRadius:10, padding:12, borderWidth:1, borderColor:COLORS.border },
  historyRow:     { flexDirection:'row', alignItems:'center', gap:8, backgroundColor:COLORS.surface, borderRadius:8, padding:10, borderWidth:1, borderColor:COLORS.border },
});
