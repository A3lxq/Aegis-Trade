// src/screens/DashboardScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Dimensions } from 'react-native';
import Svg, { Polyline, Path, Defs, LinearGradient, Stop, Circle, Line, Text as SvgText } from 'react-native-svg';
import { COLORS, SHADOWS, MOCK_TRADES, MOCK_SYMBOLS, generatePriceSeries, callClaude } from '../utils/theme';

const { width: SW } = Dimensions.get('window');

function Sparkline({ data, w, h, color }) {
  const min = Math.min(...data), max = Math.max(...data);
  const range = max - min || 1;
  const pts = data.map((v, i) => `${(i / (data.length-1)) * w},${h - ((v-min)/range)*h}`).join(' ');
  return (
    <Svg width={w} height={h}>
      <Polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round" />
    </Svg>
  );
}

export default function DashboardScreen({ tvConnected, mt5Connected }) {
  const [prices]    = useState(() => Object.fromEntries(MOCK_SYMBOLS.map(s => [s, generatePriceSeries(Math.random()*100+1, 30)])));
  const [aiSignal,  setAiSignal]  = useState(null);
  const [loading,   setLoading]   = useState(false);
  const [autoTrade, setAutoTrade] = useState(false);

  const getSignal = async () => {
    setLoading(true); setAiSignal(null);
    try {
      const r = await callClaude(
        [{ role:'user', content:'Give a EURUSD trading signal as JSON: { signal:"BUY"or"SELL"or"HOLD", entry, sl, tp, confidence, reasoning }' }],
        'Expert forex trader. Return ONLY valid JSON.'
      );
      setAiSignal(JSON.parse(r.replace(/```json|```/g,'').trim()));
    } catch { setAiSignal({ signal:'HOLD', entry:'—', sl:'—', tp:'—', confidence:50, reasoning:'Could not fetch signal.' }); }
    setLoading(false);
  };

  const STATS = [
    { l:'Balance',   v:'$12,847', c:COLORS.accent },
    { l:'Open P&L',  v:'+$237',   c:COLORS.accent },
    { l:'Win Rate',  v:'71.4%',   c:COLORS.accent4 },
    { l:'Trades',    v:'4 open',  c:COLORS.accent2 },
  ];

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 20 }}>
      <View style={styles.header}>
        <View style={styles.logoRow}>
          <View style={styles.logoBadge}><Text style={{ fontFamily:'Courier', fontWeight:'900', fontSize:14, color:'#000' }}>⚡</Text></View>
          <Text style={styles.logoText}>AEGIS-TRADE<Text style={{ color:COLORS.accent }}>AI</Text></Text>
          <Text style={styles.logoSub}>TRADER</Text>
        </View>
        <View style={{ flexDirection:'row', gap:6, alignItems:'center' }}>
          <View style={[styles.connDot, { backgroundColor: tvConnected?COLORS.accent:COLORS.danger }]} />
          <Text style={styles.connLabel}>TV</Text>
          <View style={[styles.connDot, { backgroundColor: mt5Connected?COLORS.accent:COLORS.danger }]} />
          <Text style={styles.connLabel}>MT5</Text>
        </View>
      </View>

      <View style={styles.statsGrid}>
        {STATS.map(s => (
          <View key={s.l} style={[styles.statCard, SHADOWS.card]}>
            <Text style={styles.statLabel}>{s.l}</Text>
            <Text style={[styles.statValue, { color:s.c }]}>{s.v}</Text>
          </View>
        ))}
      </View>

      {/* AI Signal */}
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>⚡ AI Signal · EURUSD</Text>
          <TouchableOpacity onPress={() => setAutoTrade(v=>!v)} style={[styles.togglePill, { borderColor: autoTrade?COLORS.accent:COLORS.border }]}>
            <Text style={{ fontSize:9, color:autoTrade?COLORS.accent:COLORS.text2, fontFamily:'Courier' }}>{autoTrade?'AUTO ON':'AUTO OFF'}</Text>
          </TouchableOpacity>
        </View>
        <TouchableOpacity onPress={getSignal} disabled={loading} style={styles.signalBtn}>
          <Text style={styles.signalBtnText}>{loading ? 'Analyzing...' : '⚡  Get AI Signal'}</Text>
        </TouchableOpacity>
        {aiSignal && (
          <View style={styles.signalCard}>
            <View style={{ flexDirection:'row', gap:10, alignItems:'center', marginBottom:8 }}>
              <View style={[styles.badge, { borderColor: aiSignal.signal==='BUY'?COLORS.accent:aiSignal.signal==='SELL'?COLORS.danger:COLORS.accent2 }]}>
                <Text style={{ color: aiSignal.signal==='BUY'?COLORS.accent:aiSignal.signal==='SELL'?COLORS.danger:COLORS.accent2, fontFamily:'Courier', fontWeight:'bold', fontSize:11 }}>{aiSignal.signal}</Text>
              </View>
              <Text style={{ fontSize:9, color:COLORS.text2, fontFamily:'Courier' }}>Confidence: {aiSignal.confidence}%</Text>
            </View>
            <View style={{ flexDirection:'row', gap:12, marginBottom:8 }}>
              {[['Entry',aiSignal.entry],['SL',aiSignal.sl],['TP',aiSignal.tp]].map(([l,v]) => (
                <View key={l}><Text style={styles.priceLabel}>{l}</Text><Text style={styles.priceVal}>{v}</Text></View>
              ))}
            </View>
            <Text style={{ fontSize:10, color:COLORS.text2, fontFamily:'Courier', lineHeight:16 }}>{aiSignal.reasoning}</Text>
          </View>
        )}
      </View>

      {/* Open positions */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Open Positions · MT5</Text>
        {MOCK_TRADES.map(t => (
          <View key={t.id} style={styles.tradeRow}>
            <View style={[styles.badge, { borderColor: t.type==='BUY'?COLORS.accent:COLORS.danger }]}>
              <Text style={{ color:t.type==='BUY'?COLORS.accent:COLORS.danger, fontFamily:'Courier', fontWeight:'bold', fontSize:9 }}>{t.type}</Text>
            </View>
            <Text style={{ fontFamily:'Courier', fontWeight:'bold', fontSize:11, color:COLORS.text, flex:1, marginLeft:8 }}>{t.symbol}</Text>
            <Text style={{ fontSize:10, color:COLORS.text2, fontFamily:'Courier' }}>{t.entry}</Text>
            <Text style={[styles.pnl, { color:t.pnl>0?COLORS.accent:COLORS.danger }]}>{t.pnl>0?'+':''}${t.pnl.toFixed(2)}</Text>
          </View>
        ))}
      </View>

      {/* Market scanner */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Market Scanner</Text>
        {MOCK_SYMBOLS.slice(0,6).map(sym => {
          const p = prices[sym];
          const chg = ((p[p.length-1]-p[p.length-5])/p[p.length-5]*100).toFixed(2);
          const up  = parseFloat(chg) >= 0;
          return (
            <View key={sym} style={styles.scannerRow}>
              <Text style={{ fontFamily:'Courier', fontWeight:'bold', fontSize:12, color:COLORS.text, width:72 }}>{sym}</Text>
              <Text style={{ fontSize:10, color:up?COLORS.accent:COLORS.danger, fontFamily:'Courier', flex:1 }}>{up?'▲':'▼'} {Math.abs(parseFloat(chg))}%</Text>
              <Sparkline data={p.slice(-20)} w={60} h={22} color={up?COLORS.accent:COLORS.danger} />
            </View>
          );
        })}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:    { flex:1, backgroundColor:COLORS.bg },
  header:       { flexDirection:'row', alignItems:'center', justifyContent:'space-between', padding:16, paddingTop:50, borderBottomWidth:1, borderBottomColor:COLORS.border },
  logoRow:      { flexDirection:'row', alignItems:'center', gap:8 },
  logoBadge:    { width:28, height:28, borderRadius:6, backgroundColor:COLORS.accent, alignItems:'center', justifyContent:'center' },
  logoText:     { fontFamily:'Courier', fontWeight:'900', fontSize:16, color:COLORS.text },
  logoSub:      { fontSize:9, color:COLORS.text3, fontFamily:'Courier', letterSpacing:1 },
  connDot:      { width:7, height:7, borderRadius:4 },
  connLabel:    { fontSize:9, color:COLORS.text2, fontFamily:'Courier' },
  statsGrid:    { flexDirection:'row', flexWrap:'wrap', gap:8, padding:16 },
  statCard:     { flex:1, minWidth:'46%', backgroundColor:COLORS.surface, borderRadius:10, padding:12, borderWidth:1, borderColor:COLORS.border },
  statLabel:    { fontSize:9, color:COLORS.text3, fontFamily:'Courier', textTransform:'uppercase' },
  statValue:    { fontSize:18, fontWeight:'900', fontFamily:'Courier', marginTop:3 },
  section:      { padding:16, paddingTop:0, marginTop:12 },
  sectionHeader:{ flexDirection:'row', alignItems:'center', justifyContent:'space-between', marginBottom:8 },
  sectionTitle: { fontSize:10, color:COLORS.text2, fontFamily:'Courier', textTransform:'uppercase', letterSpacing:0.5, marginBottom:8, fontWeight:'bold' },
  togglePill:   { paddingHorizontal:8, paddingVertical:3, borderRadius:4, borderWidth:1 },
  signalBtn:    { backgroundColor:COLORS.accent, borderRadius:8, padding:12, alignItems:'center', marginBottom:10 },
  signalBtnText:{ color:'#000', fontFamily:'Courier', fontWeight:'900', fontSize:12 },
  signalCard:   { backgroundColor:COLORS.surface2, borderRadius:10, padding:12, borderWidth:1, borderColor:COLORS.border },
  badge:        { paddingHorizontal:7, paddingVertical:2, borderRadius:4, borderWidth:1 },
  priceLabel:   { fontSize:8, color:COLORS.text3, fontFamily:'Courier' },
  priceVal:     { fontSize:12, color:COLORS.text, fontFamily:'Courier', fontWeight:'bold' },
  tradeRow:     { flexDirection:'row', alignItems:'center', backgroundColor:COLORS.surface, borderRadius:8, padding:10, marginBottom:6, borderWidth:1, borderColor:COLORS.border },
  pnl:          { fontSize:11, fontFamily:'Courier', fontWeight:'bold', marginLeft:'auto' },
  scannerRow:   { flexDirection:'row', alignItems:'center', backgroundColor:COLORS.surface, borderRadius:8, padding:10, marginBottom:6, borderWidth:1, borderColor:COLORS.border },
});
