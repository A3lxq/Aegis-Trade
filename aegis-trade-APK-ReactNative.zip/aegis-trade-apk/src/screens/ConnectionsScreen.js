// src/screens/ConnectionsScreen.js
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { COLORS } from '../utils/theme';

export default function ConnectionsScreen({ tvConnected, setTvConnected, mt5Connected, setMt5Connected }) {
  const [tvUser,    setTvUser]    = useState('');
  const [tvPass,    setTvPass]    = useState('');
  const [mt5Server, setMt5Server] = useState('');
  const [mt5Login,  setMt5Login]  = useState('');
  const [mt5Pass,   setMt5Pass]   = useState('');
  const [connecting, setConnecting] = useState('');

  const connect = (type) => {
    setConnecting(type);
    setTimeout(() => {
      if (type==='tv') { setTvConnected(true); Alert.alert('✓ TradingView Connected', 'Chart data is now streaming.'); }
      else             { setMt5Connected(true); Alert.alert('✓ MetaTrader 5 Connected', 'Trade execution is ready.'); }
      setConnecting('');
    }, 2000);
  };

  const RISK_PARAMS = [
    ['Max Risk per Trade (%)','1.0'],['Max Daily Drawdown (%)','5.0'],
    ['Max Open Trades','5'],['Max Lot Size','1.0'],
  ];

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom:40 }}>
      <View style={styles.header}><Text style={styles.headerText}>Connections</Text></View>

      <View style={styles.infoBox}>
        <Text style={{ fontSize:11, color:COLORS.accent, fontFamily:'Courier', lineHeight:17 }}>
          Connect your TradingView and MT5 accounts to enable autonomous AI trading. Credentials are encrypted.
        </Text>
      </View>

      {/* TradingView */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={styles.tvBadge}><Text style={{ color:'#fff', fontFamily:'Courier', fontWeight:'900', fontSize:11 }}>TV</Text></View>
          <View style={{ flex:1, marginLeft:10 }}>
            <Text style={styles.cardTitle}>TradingView</Text>
            <Text style={{ fontSize:9, color:COLORS.text3, fontFamily:'Courier' }}>Chart analysis & signal source</Text>
          </View>
          <View style={[styles.statusDot, { backgroundColor: tvConnected?COLORS.accent:COLORS.danger }]} />
          <Text style={{ fontSize:9, color: tvConnected?COLORS.accent:COLORS.danger, fontFamily:'Courier', marginLeft:4 }}>
            {tvConnected?'Connected':'Offline'}
          </Text>
        </View>
        {!tvConnected ? (
          <View style={styles.cardBody}>
            <TextInput style={styles.input} placeholder="TradingView username" placeholderTextColor={COLORS.text3} value={tvUser} onChangeText={setTvUser} autoCapitalize="none" />
            <TextInput style={styles.input} placeholder="Password" placeholderTextColor={COLORS.text3} value={tvPass} onChangeText={setTvPass} secureTextEntry />
            <TouchableOpacity onPress={() => connect('tv')} disabled={connecting==='tv'} style={[styles.connectBtn, { backgroundColor:COLORS.accent2 }]}>
              {connecting==='tv' ? <><ActivityIndicator size="small" color="#fff" /><Text style={styles.connectBtnText}>  Connecting...</Text></>
                                : <Text style={styles.connectBtnText}>Connect TradingView</Text>}
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.cardBody}>
            <Text style={{ fontSize:11, color:COLORS.text2, fontFamily:'Courier', lineHeight:17, marginBottom:10 }}>
              Streaming EURUSD, GBPUSD, XAUUSD, BTCUSD, NASDAQ{'\n'}Timeframes: M1, M5, H1, H4, D1
            </Text>
            <TouchableOpacity onPress={() => setTvConnected(false)} style={[styles.disconnectBtn]}>
              <Text style={{ color:COLORS.danger, fontFamily:'Courier', fontSize:11 }}>Disconnect</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* MetaTrader 5 */}
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={styles.mt5Badge}><Text style={{ color:COLORS.accent2, fontFamily:'Courier', fontWeight:'900', fontSize:11 }}>MT5</Text></View>
          <View style={{ flex:1, marginLeft:10 }}>
            <Text style={styles.cardTitle}>MetaTrader 5</Text>
            <Text style={{ fontSize:9, color:COLORS.text3, fontFamily:'Courier' }}>Trade execution engine</Text>
          </View>
          <View style={[styles.statusDot, { backgroundColor: mt5Connected?COLORS.accent:COLORS.danger }]} />
          <Text style={{ fontSize:9, color: mt5Connected?COLORS.accent:COLORS.danger, fontFamily:'Courier', marginLeft:4 }}>
            {mt5Connected?'Connected':'Offline'}
          </Text>
        </View>
        {!mt5Connected ? (
          <View style={styles.cardBody}>
            <TextInput style={styles.input} placeholder="Broker server (e.g. ICMarkets-Live02)" placeholderTextColor={COLORS.text3} value={mt5Server} onChangeText={setMt5Server} autoCapitalize="none" />
            <TextInput style={styles.input} placeholder="Account login number" placeholderTextColor={COLORS.text3} value={mt5Login} onChangeText={setMt5Login} keyboardType="numeric" />
            <TextInput style={styles.input} placeholder="Password" placeholderTextColor={COLORS.text3} value={mt5Pass} onChangeText={setMt5Pass} secureTextEntry />
            <TouchableOpacity onPress={() => connect('mt5')} disabled={connecting==='mt5'} style={[styles.connectBtn, { backgroundColor:'#1a3a5c' }]}>
              {connecting==='mt5' ? <><ActivityIndicator size="small" color={COLORS.accent2} /><Text style={[styles.connectBtnText,{color:COLORS.accent2}]}>  Connecting...</Text></>
                                  : <Text style={[styles.connectBtnText,{color:COLORS.accent2}]}>Connect MetaTrader 5</Text>}
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.cardBody}>
            <View style={{ flexDirection:'row', gap:8, marginBottom:10 }}>
              {[['Balance','$12,847'],['Leverage','1:100'],['Type','Live']].map(([l,v]) => (
                <View key={l} style={styles.miniStat}>
                  <Text style={{ fontSize:8, color:COLORS.text3, fontFamily:'Courier' }}>{l}</Text>
                  <Text style={{ fontSize:12, color:COLORS.text, fontFamily:'Courier', fontWeight:'bold' }}>{v}</Text>
                </View>
              ))}
            </View>
            <TouchableOpacity onPress={() => setMt5Connected(false)} style={styles.disconnectBtn}>
              <Text style={{ color:COLORS.danger, fontFamily:'Courier', fontSize:11 }}>Disconnect</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Risk settings */}
      <View style={styles.card}>
        <View style={styles.cardHeader}><Text style={styles.cardTitle}>⚙ Risk Management</Text></View>
        <View style={styles.cardBody}>
          <View style={{ flexDirection:'row', flexWrap:'wrap', gap:10 }}>
            {RISK_PARAMS.map(([l,d]) => (
              <View key={l} style={{ width:'47%' }}>
                <Text style={{ fontSize:8, color:COLORS.text3, fontFamily:'Courier', marginBottom:4 }}>{l}</Text>
                <TextInput style={[styles.input, { marginBottom:0 }]} defaultValue={d} keyboardType="decimal-pad" />
              </View>
            ))}
          </View>
          <TouchableOpacity style={[styles.connectBtn, { backgroundColor:COLORS.accent, marginTop:14 }]}>
            <Text style={[styles.connectBtnText, { color:'#000' }]}>Save Settings</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:      { flex:1, backgroundColor:COLORS.bg },
  header:         { padding:16, paddingTop:50, borderBottomWidth:1, borderBottomColor:COLORS.border },
  headerText:     { fontSize:18, fontFamily:'Courier', fontWeight:'900', color:COLORS.text },
  infoBox:        { margin:16, padding:14, backgroundColor:'rgba(0,212,170,0.06)', borderRadius:8, borderLeftWidth:3, borderLeftColor:COLORS.accent },
  card:           { margin:16, marginTop:0, marginBottom:14, backgroundColor:COLORS.surface, borderRadius:12, borderWidth:1, borderColor:COLORS.border, overflow:'hidden' },
  cardHeader:     { flexDirection:'row', alignItems:'center', padding:14, backgroundColor:COLORS.surface2, borderBottomWidth:1, borderBottomColor:COLORS.border },
  tvBadge:        { width:32, height:32, borderRadius:6, backgroundColor:'#2962ff', alignItems:'center', justifyContent:'center' },
  mt5Badge:       { width:32, height:32, borderRadius:6, backgroundColor:'#1a3a5c', alignItems:'center', justifyContent:'center' },
  cardTitle:      { fontSize:13, fontFamily:'Courier', fontWeight:'bold', color:COLORS.text },
  statusDot:      { width:7, height:7, borderRadius:4 },
  cardBody:       { padding:14 },
  input:          { backgroundColor:COLORS.bg2, borderWidth:1, borderColor:COLORS.border, borderRadius:8, padding:11, color:COLORS.text, fontFamily:'Courier', fontSize:12, marginBottom:10 },
  connectBtn:     { borderRadius:8, padding:13, flexDirection:'row', alignItems:'center', justifyContent:'center' },
  connectBtnText: { color:'#fff', fontFamily:'Courier', fontWeight:'bold', fontSize:12 },
  disconnectBtn:  { borderWidth:1, borderColor:COLORS.danger, borderRadius:6, padding:9, alignItems:'center' },
  miniStat:       { flex:1, backgroundColor:COLORS.bg2, borderRadius:6, padding:8 },
});
