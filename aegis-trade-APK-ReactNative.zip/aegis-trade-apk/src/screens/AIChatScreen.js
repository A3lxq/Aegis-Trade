// src/screens/AIChatScreen.js
import React, { useState, useRef, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { COLORS, callClaude } from '../utils/theme';

const SUGGESTIONS = ['Analyze gold right now','Best scalping times for XAUUSD','Explain RSI divergence','Improve my win rate','Risk management rules'];

export default function AIChatScreen() {
  const [messages, setMessages] = useState([
    { role:'assistant', content:"Hello! I'm your Aegis-Trade AI assistant. I can analyze markets, explain strategies, review your performance, or answer any trading question. How can I help?" }
  ]);
  const [input, setInput]   = useState('');
  const [loading, setLoading] = useState(false);
  const scrollRef             = useRef();

  useEffect(() => { scrollRef.current?.scrollToEnd({ animated: true }); }, [messages]);

  const send = async () => {
    if (!input.trim() || loading) return;
    const userMsg = { role:'user', content: input.trim() };
    setMessages(p => [...p, userMsg]);
    setInput('');
    setLoading(true);
    const history = [...messages, userMsg].map(m => ({ role:m.role, content:m.content }));
    const reply = await callClaude(history, 'You are an expert AI trading assistant. You specialize in forex, gold (XAUUSD), stocks, crypto, technical analysis, and risk management. Be concise and practical.');
    setMessages(p => [...p, { role:'assistant', content:reply }]);
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS==='ios'?'padding':'height'}>
      <View style={styles.header}>
        <View style={styles.aiIcon}><Text style={{ fontSize:16 }}>⚡</Text></View>
        <View>
          <Text style={styles.headerTitle}>Trading AI Assistant</Text>
          <Text style={{ fontSize:9, color:COLORS.accent, fontFamily:'Courier' }}>● Online · Claude AI</Text>
        </View>
      </View>

      <ScrollView ref={scrollRef} style={styles.messageArea} contentContainerStyle={{ paddingVertical:12, gap:10 }} showsVerticalScrollIndicator={false}>
        {messages.map((m, i) => (
          <View key={i} style={[styles.messageRow, { flexDirection: m.role==='user'?'row-reverse':'row' }]}>
            {m.role==='assistant' && <View style={styles.aiBubbleIcon}><Text style={{ fontSize:11 }}>⚡</Text></View>}
            <View style={[styles.bubble, m.role==='user' ? styles.userBubble : styles.aiBubble, { maxWidth:'80%' }]}>
              <Text style={[styles.bubbleText, { color: m.role==='user'?'#fff':COLORS.text }]}>{m.content}</Text>
            </View>
          </View>
        ))}
        {loading && (
          <View style={[styles.messageRow, { flexDirection:'row' }]}>
            <View style={styles.aiBubbleIcon}><Text style={{ fontSize:11 }}>⚡</Text></View>
            <View style={[styles.aiBubble, { padding:12, flexDirection:'row', gap:6 }]}>
              {[0,1,2].map(i => <View key={i} style={[styles.typingDot, { opacity: 0.4 + i*0.2 }]} />)}
            </View>
          </View>
        )}
      </ScrollView>

      {messages.length <= 1 && (
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.suggestions}>
          {SUGGESTIONS.map(s => (
            <TouchableOpacity key={s} onPress={() => setInput(s)} style={styles.suggBtn}>
              <Text style={styles.suggText}>{s}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      )}

      <View style={styles.inputRow}>
        <TextInput
          style={styles.input} placeholder="Ask anything about trading..." placeholderTextColor={COLORS.text3}
          value={input} onChangeText={setInput} onSubmitEditing={send} returnKeyType="send"
          multiline maxLength={500}
        />
        <TouchableOpacity onPress={send} disabled={loading} style={[styles.sendBtn, (!input.trim()||loading) && { opacity:0.4 }]}>
          <Text style={styles.sendBtnText}>▶</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container:      { flex:1, backgroundColor:COLORS.bg },
  header:         { flexDirection:'row', alignItems:'center', gap:10, padding:16, paddingTop:50, borderBottomWidth:1, borderBottomColor:COLORS.border, backgroundColor:COLORS.bg2 },
  aiIcon:         { width:32, height:32, borderRadius:16, backgroundColor:COLORS.accent, alignItems:'center', justifyContent:'center' },
  headerTitle:    { fontSize:14, fontFamily:'Courier', fontWeight:'900', color:COLORS.text },
  messageArea:    { flex:1, paddingHorizontal:14 },
  messageRow:     { flexDirection:'row', alignItems:'flex-end', gap:8, marginBottom:4 },
  aiBubbleIcon:   { width:26, height:26, borderRadius:13, backgroundColor:COLORS.accent, alignItems:'center', justifyContent:'center', flexShrink:0 },
  bubble:         { borderRadius:14, padding:12 },
  userBubble:     { backgroundColor:COLORS.accent2, borderBottomRightRadius:4 },
  aiBubble:       { backgroundColor:COLORS.surface2, borderBottomLeftRadius:4, borderWidth:1, borderColor:COLORS.border },
  bubbleText:     { fontSize:12, fontFamily:'Courier', lineHeight:18 },
  typingDot:      { width:7, height:7, borderRadius:4, backgroundColor:COLORS.accent },
  suggestions:    { paddingHorizontal:14, paddingVertical:8 },
  suggBtn:        { backgroundColor:COLORS.surface, borderWidth:1, borderColor:COLORS.border2, borderRadius:16, paddingHorizontal:12, paddingVertical:7, marginRight:8 },
  suggText:       { fontSize:10, color:COLORS.text2, fontFamily:'Courier' },
  inputRow:       { flexDirection:'row', gap:8, padding:14, paddingBottom:24, borderTopWidth:1, borderTopColor:COLORS.border, backgroundColor:COLORS.bg2 },
  input:          { flex:1, backgroundColor:COLORS.bg, borderWidth:1, borderColor:COLORS.border, borderRadius:10, paddingHorizontal:14, paddingVertical:10, color:COLORS.text, fontFamily:'Courier', fontSize:12, maxHeight:100 },
  sendBtn:        { width:42, height:42, borderRadius:10, backgroundColor:COLORS.accent, alignItems:'center', justifyContent:'center' },
  sendBtnText:    { color:'#000', fontSize:14, fontWeight:'900' },
});
