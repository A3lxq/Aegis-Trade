// src/screens/StrategyScreen.js
import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, TextInput, StyleSheet, ActivityIndicator } from 'react-native';
import { COLORS, callClaude } from '../utils/theme';

const TEMPLATES = [
  { name:'EMA Crossover', text:'Entry: When EMA(9) crosses above EMA(21) on H1 chart\nFilter: RSI(14) > 50\nStop Loss: 20 pips below entry\nTake Profit: 40 pips (1:2 RR)\nTime filter: London + NY sessions only' },
  { name:'RSI Reversal',  text:'Entry Long: RSI(14) < 30, price at support zone\nEntry Short: RSI(14) > 70, price at resistance zone\nConfirmation: Engulfing candle\nStop Loss: Beyond swing high/low\nTake Profit: 1:2.5 RR' },
];

export default function StrategyScreen() {
  const [name, setName]     = useState('');
  const [text, setText]     = useState('');
  const [insight, setInsight] = useState(null);
  const [loading, setLoading] = useState(false);

  const getInsight = async () => {
    if (!text.trim()) return;
    setLoading(true); setInsight(null);
    try {
      const r = await callClaude(
        [{ role:'user', content:`Analyze this trading strategy:\n${text}\n\nReturn JSON: { strengths:[], weaknesses:[], bestMarkets:string, riskLevel:string, improvements:[], rating:number, summary:string }` }],
        'Expert quantitative trading analyst. Return ONLY valid JSON.'
      );
      setInsight(JSON.parse(r.replace(/```json|```/g,'').trim()));
    } catch { setInsight({ strengths:['Submitted'], weaknesses:['Needs detail'], bestMarkets:'Various', riskLevel:'Medium', improvements:[], rating:6, summary:'Analysis unavailable.' }); }
    setLoading(false);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom:30 }}>
      <View style={styles.header}><Text style={styles.headerText}>Strategy Lab</Text></View>

      <View style={styles.section}>
        <Text style={styles.label}>Strategy Name</Text>
        <TextInput style={styles.input} placeholder="e.g. My EMA Setup" placeholderTextColor={COLORS.text3} value={name} onChangeText={setName} />

        <Text style={[styles.label, { marginTop:12 }]}>Quick Templates</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom:10 }}>
          {TEMPLATES.map(t => (
            <TouchableOpacity key={t.name} onPress={() => { setName(t.name); setText(t.text); }}
              style={styles.templateBtn}><Text style={styles.templateBtnText}>{t.name}</Text></TouchableOpacity>
          ))}
        </ScrollView>

        <Text style={[styles.label]}>Strategy Description</Text>
        <TextInput
          style={[styles.input, { height:180, textAlignVertical:'top', lineHeight:18 }]}
          placeholder={'Describe your strategy:\n\nEntry rules\nExit rules\nStop loss\nTake profit\nRisk management...'}
          placeholderTextColor={COLORS.text3}
          multiline value={text} onChangeText={setText}
        />

        <TouchableOpacity onPress={getInsight} disabled={loading || !text.trim()}
          style={[styles.aiBtn, (loading || !text.trim()) && { opacity:0.5 }]}>
          {loading ? <><ActivityIndicator size="small" color="#000" /><Text style={styles.aiBtnText}>  Analyzing...</Text></>
                   : <Text style={styles.aiBtnText}>⚡  GET AI INSIGHTS</Text>}
        </TouchableOpacity>
      </View>

      {insight && (
        <View style={styles.insightCard}>
          <View style={{ flexDirection:'row', justifyContent:'space-between', alignItems:'center', marginBottom:10 }}>
            <Text style={[styles.label, { color:COLORS.accent }]}>AI Insights</Text>
            <Text style={{ fontSize:22, fontWeight:'900', color: insight.rating>=7?COLORS.accent:insight.rating>=5?COLORS.accent3:COLORS.danger, fontFamily:'Courier' }}>{insight.rating}/10</Text>
          </View>

          <View style={{ backgroundColor:COLORS.bg2, borderRadius:8, padding:10, marginBottom:10, borderLeftWidth:3, borderLeftColor:COLORS.accent }}>
            <Text style={{ fontSize:11, color:COLORS.text, fontFamily:'Courier', lineHeight:17 }}>{insight.summary}</Text>
          </View>

          <View style={{ flexDirection:'row', gap:8, marginBottom:10 }}>
            <View style={[styles.insightBox, { borderColor:'rgba(0,212,170,0.2)', flex:1 }]}>
              <Text style={{ fontSize:9, color:COLORS.accent, fontFamily:'Courier', marginBottom:4 }}>✓ STRENGTHS</Text>
              {(insight.strengths||[]).map((s,i) => <Text key={i} style={styles.insightItem}>• {s}</Text>)}
            </View>
            <View style={[styles.insightBox, { borderColor:'rgba(255,69,96,0.2)', flex:1 }]}>
              <Text style={{ fontSize:9, color:COLORS.danger, fontFamily:'Courier', marginBottom:4 }}>✗ WEAKNESSES</Text>
              {(insight.weaknesses||[]).map((w,i) => <Text key={i} style={styles.insightItem}>• {w}</Text>)}
            </View>
          </View>

          <View style={{ flexDirection:'row', gap:8, marginBottom:10 }}>
            <View style={[styles.miniBox, { flex:1 }]}><Text style={styles.miniLabel}>Best Markets</Text><Text style={styles.miniVal}>{insight.bestMarkets}</Text></View>
            <View style={[styles.miniBox, { flex:1 }]}><Text style={styles.miniLabel}>Risk Level</Text><Text style={[styles.miniVal, { color: insight.riskLevel==='High'?COLORS.danger:insight.riskLevel==='Low'?COLORS.accent:COLORS.accent3 }]}>{insight.riskLevel}</Text></View>
          </View>

          {(insight.improvements||[]).map((imp,i) => (
            <View key={i} style={{ paddingLeft:8, borderLeftWidth:2, borderLeftColor:COLORS.accent2, marginBottom:6 }}>
              <Text style={{ fontSize:11, color:COLORS.text2, fontFamily:'Courier' }}>→ {imp}</Text>
            </View>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:    { flex:1, backgroundColor:COLORS.bg },
  header:       { padding:16, paddingTop:50, borderBottomWidth:1, borderBottomColor:COLORS.border },
  headerText:   { fontSize:18, fontFamily:'Courier', fontWeight:'900', color:COLORS.text },
  section:      { padding:16 },
  label:        { fontSize:9, color:COLORS.text3, fontFamily:'Courier', textTransform:'uppercase', letterSpacing:0.5, marginBottom:6 },
  input:        { backgroundColor:COLORS.bg2, borderWidth:1, borderColor:COLORS.border, borderRadius:8, padding:12, color:COLORS.text, fontFamily:'Courier', fontSize:12 },
  templateBtn:  { backgroundColor:COLORS.surface, borderWidth:1, borderColor:COLORS.border2, borderRadius:6, paddingHorizontal:12, paddingVertical:7, marginRight:8 },
  templateBtnText:{ fontSize:10, color:COLORS.text2, fontFamily:'Courier' },
  aiBtn:        { backgroundColor:COLORS.accent, borderRadius:8, padding:14, flexDirection:'row', alignItems:'center', justifyContent:'center', marginTop:14 },
  aiBtnText:    { color:'#000', fontFamily:'Courier', fontWeight:'900', fontSize:12 },
  insightCard:  { margin:16, backgroundColor:COLORS.surface, borderRadius:12, padding:14, borderWidth:1, borderColor:COLORS.border },
  insightBox:   { backgroundColor:COLORS.bg2, borderRadius:8, padding:10, borderWidth:1 },
  insightItem:  { fontSize:10, color:COLORS.text2, fontFamily:'Courier', marginBottom:2 },
  miniBox:      { backgroundColor:COLORS.bg2, borderRadius:8, padding:10 },
  miniLabel:    { fontSize:8, color:COLORS.text3, fontFamily:'Courier', textTransform:'uppercase' },
  miniVal:      { fontSize:12, color:COLORS.text, fontFamily:'Courier', fontWeight:'bold', marginTop:2 },
});
