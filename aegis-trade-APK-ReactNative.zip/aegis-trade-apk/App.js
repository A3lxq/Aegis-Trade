// App.js - Root entry point for Aegis-Trade (React Native / Expo)
import React, { useState, useEffect } from 'react';
import { StatusBar, View, Text, TouchableOpacity, StyleSheet, SafeAreaView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import DashboardScreen   from './src/screens/DashboardScreen';
import GoldScalperScreen from './src/screens/GoldScalperScreen';
import StrategyScreen    from './src/screens/StrategyScreen';
import HistoryScreen     from './src/screens/HistoryScreen';
import AIChatScreen      from './src/screens/AIChatScreen';
import ConnectionsScreen from './src/screens/ConnectionsScreen';

import { COLORS } from './src/utils/theme';

const Tab = createBottomTabNavigator();

// ── Tab icon component ──────────────────────────────────────────────────────
function TabIcon({ label, focused, isGold }) {
  const icons = {
    Dashboard:   '◉',
    'Gold Scalper': '🥇',
    Strategies:  '⚙',
    History:     '📊',
    'AI Chat':   '⚡',
    Connections: '🔗',
  };
  const activeColor = isGold ? COLORS.gold : COLORS.accent;
  return (
    <View style={{ alignItems: 'center', paddingTop: 4 }}>
      <Text style={{ fontSize: 18 }}>{icons[label] || '●'}</Text>
      <Text style={{ fontSize: 9, marginTop: 2, fontFamily: 'Courier', color: focused ? activeColor : COLORS.text3, letterSpacing: 0.5 }}>
        {label.toUpperCase()}
      </Text>
    </View>
  );
}

// ── Connection state (global context via props drilling) ────────────────────
export default function App() {
  const [tvConnected,  setTvConnected]  = useState(false);
  const [mt5Connected, setMt5Connected] = useState(false);

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <StatusBar barStyle="light-content" backgroundColor={COLORS.bg} />
        <NavigationContainer
          theme={{
            dark: true,
            colors: {
              primary:    COLORS.accent,
              background: COLORS.bg,
              card:       COLORS.bg2,
              text:       COLORS.text,
              border:     COLORS.border,
              notification: COLORS.accent3,
            },
          }}
        >
          <Tab.Navigator
            screenOptions={{
              headerShown: false,
              tabBarStyle: {
                backgroundColor: COLORS.bg2,
                borderTopColor:  COLORS.border,
                borderTopWidth:  1,
                height: 70,
                paddingBottom: 8,
              },
              tabBarShowLabel: false,
            }}
          >
            <Tab.Screen name="Dashboard"
              options={{ tabBarIcon: ({ focused }) => <TabIcon label="Dashboard" focused={focused} /> }}>
              {() => <DashboardScreen tvConnected={tvConnected} mt5Connected={mt5Connected} />}
            </Tab.Screen>

            <Tab.Screen name="Gold Scalper"
              options={{ tabBarIcon: ({ focused }) => <TabIcon label="Gold Scalper" focused={focused} isGold /> }}>
              {() => <GoldScalperScreen tvConnected={tvConnected} mt5Connected={mt5Connected} />}
            </Tab.Screen>

            <Tab.Screen name="Strategies"
              options={{ tabBarIcon: ({ focused }) => <TabIcon label="Strategies" focused={focused} /> }}>
              {() => <StrategyScreen />}
            </Tab.Screen>

            <Tab.Screen name="History"
              options={{ tabBarIcon: ({ focused }) => <TabIcon label="History" focused={focused} /> }}>
              {() => <HistoryScreen />}
            </Tab.Screen>

            <Tab.Screen name="AI Chat"
              options={{ tabBarIcon: ({ focused }) => <TabIcon label="AI Chat" focused={focused} /> }}>
              {() => <AIChatScreen />}
            </Tab.Screen>

            <Tab.Screen name="Connections"
              options={{ tabBarIcon: ({ focused }) => <TabIcon label="Connections" focused={focused} /> }}>
              {() => (
                <ConnectionsScreen
                  tvConnected={tvConnected}   setTvConnected={setTvConnected}
                  mt5Connected={mt5Connected} setMt5Connected={setMt5Connected}
                />
              )}
            </Tab.Screen>
          </Tab.Navigator>
        </NavigationContainer>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
