<p align="center">
  <img src="assets/icon.png" width="96" height="96" alt="Aegis-Trade Logo" />
</p>

<h1 align="center">Aegis-Trade</h1>
<p align="center"><b>Autonomous AI Trading Platform — Windows Desktop (.exe)</b></p>
<p align="center">
  <img src="https://img.shields.io/badge/version-2.5.0-00d4aa?style=flat-square" />
  <img src="https://img.shields.io/badge/platform-Windows%2010%2F11-0078D4?style=flat-square&logo=windows" />
  <img src="https://img.shields.io/badge/built%20with-Electron%20%2B%20React-0099ff?style=flat-square" />
  <img src="https://img.shields.io/badge/AI-Claude%20API-9b59ff?style=flat-square" />
</p>

---

## Overview

**Aegis-Trade** is an autonomous AI-powered trading desktop application for Windows. Connect your **TradingView** account for live chart analysis and your **MetaTrader 5** account for automated trade execution. The AI engine — powered by **Claude** — analyses market conditions in real time and executes high-probability trades autonomously.

The app ships as both a **full Windows installer** (`.exe` setup wizard with Start Menu and desktop shortcuts) and a **portable single-file executable** (no installation required).

---

## Features

| Module | Description |
|---|---|
| ◉ **Dashboard** | Live candlestick charts for 8 symbols, AI trade signals, open positions table, market scanner with sparklines, equity curve |
| 🥇 **Gold Scalper** | Dedicated XAUUSD module — live M5 chart with EMA 8/21, 4 session tracker (Asian/London/NY/Overlap), AI scalp signals with dual take-profits, quick BUY/SELL panel, 5 curated setups, economic news calendar, real-time P&L with progress bars |
| ⚙ **Strategies** | Write or upload strategies. Claude AI analyses them (strengths, weaknesses, rating /10, improvements) **before** backtesting. Full backtest engine with equity curve, Sharpe ratio, profit factor |
| 📊 **History** | Complete trade history with win/loss filter and AI performance review |
| ⚡ **AI Chat** | Persistent Claude AI trading assistant — multi-turn conversations about markets, strategies, risk management |
| 🔗 **Connections** | TradingView + MT5 account login, risk management settings panel |

### Desktop-Exclusive Features
- 🖼️ Custom frameless window with macOS-style traffic-light controls
- ⌨️ Keyboard shortcuts `Ctrl+1` through `Ctrl+6` for instant screen navigation
- 📋 Native application menu with Trading submenu
- 📡 Live scrolling ticker bar with real-time price updates
- 🔄 Full-screen toggle (`F11`)

---

## Tech Stack

| Layer | Technology |
|---|---|
| Shell | Electron 30 |
| UI Framework | React 18 + JSX |
| Bundler | Create React App (react-scripts) |
| Installer | electron-builder (NSIS) |
| Charts | Custom SVG candlestick renderer |
| AI Engine | Anthropic Claude API (`claude-sonnet-4-20250514`) |
| IPC | Electron contextBridge (secure preload) |

---

## Project Structure

```
aegis-trade-exe/
├── package.json                    # Dependencies + electron-builder config
├── public/
│   └── index.html                  # HTML entry point (CSP headers)
├── assets/
│   ├── icon.ico                    # Windows app icon
│   └── icon.png                    # Generic icon
└── src/
    ├── main/
    │   ├── main.js                 # Electron main process
    │   └── preload.js              # Secure IPC bridge (contextBridge)
    └── renderer/
        ├── index.js                # React entry point
        ├── App.jsx                 # All screens + root app
        ├── utils.js                # Colours, helpers, callClaude(), mock data
        └── components/
            ├── TitleBar.jsx        # Custom frameless title bar + nav
            └── TickerBar.jsx       # Live scrolling price ticker
```

---

## Build the .EXE

### Prerequisites

- **Node.js 18+** — https://nodejs.org
- **Windows 10 or 11** is recommended for building (can also build on macOS/Linux, though Windows installer output is best on Windows)
- ~500 MB disk space for node_modules + build output

---

### Step 1 — Install dependencies

```bash
cd aegis-trade-exe
npm install
```

---

### Step 2 — Run in development mode

Test the app before building:

```bash
npm run dev
```

This starts React dev server on port 3000 and launches Electron pointing at it. Live reload is enabled.

---

### Step 3 — Build the production .EXE

**NSIS Installer** (recommended — includes wizard, desktop shortcut, Start Menu, Add/Remove Programs):
```bash
npm run build:exe
```

**Portable EXE** (single file, no installation needed — just double-click):
```bash
npm run build:portable
```

**Both at once:**
```bash
npm run dist
```

Output appears in `dist-exe/`:
```
dist-exe/
├── Aegis-Trade Setup 2.5.0.exe     ← Installer (share this for normal users)
└── Aegis-Trade 2.5.0.exe           ← Portable (share this for power users)
```

Build time is approximately **3–6 minutes**.

---

### Step 4 — Build for 32-bit Windows

For older systems (Windows 7/8/10 32-bit):
```bash
npm run build:exe:32
```

---

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl + 1` | Dashboard |
| `Ctrl + 2` | Gold Scalper |
| `Ctrl + 3` | Strategies |
| `Ctrl + 4` | Trade History |
| `Ctrl + 5` | AI Chat |
| `Ctrl + 6` | Connections |
| `Ctrl + R` | Reload app |
| `F11` | Toggle fullscreen |
| `F12` | Toggle DevTools |
| `Ctrl + Q` | Quit |

---

## Configuration

### App Icon
Replace `assets/icon.ico` with your own **256×256 `.ico`** file.
Use **https://convertio.co/png-ico** to convert PNG → ICO.

You also need `assets/icon.png` as a fallback for Linux/macOS builds.

### App Name & ID
Edit `package.json` under the `"build"` key:
```json
"build": {
  "appId":       "com.aegistrade.app",
  "productName": "Aegis-Trade"
}
```

### Installer Options
Edit `package.json` under `"build" → "nsis"`:
```json
"nsis": {
  "oneClick": false,
  "allowToChangeInstallationDirectory": true,
  "createDesktopShortcut": true,
  "shortcutName": "Aegis-Trade"
}
```

### Window Size
Edit `src/main/main.js`:
```js
mainWindow = new BrowserWindow({
  width:  1280,   // default width
  height: 820,    // default height
  minWidth:  1024,
  minHeight: 700,
});
```

---

## Auto-Updates (Optional)

To add automatic app updates, install `electron-updater`:

```bash
npm install electron-updater
```

Then in `main.js`:
```js
const { autoUpdater } = require('electron-updater');
app.whenReady().then(() => {
  autoUpdater.checkForUpdatesAndNotify();
});
```

Host your releases on GitHub Releases and set `publish` in `package.json`.

---

## API Key Security

> ⚠️ **Do not hardcode your Anthropic API key in the source code.**

For production, route all Claude API calls through a backend proxy:

```
Desktop App → POST https://your-server.com/api/claude → Anthropic API
```

**Example Express proxy (Node.js):**
```js
const express = require('express');
const app     = express();

app.post('/api/claude', authenticateUser, async (req, res) => {
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key':    process.env.ANTHROPIC_API_KEY,  // server-side only
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify(req.body),
  });
  res.json(await response.json());
});

app.listen(3001);
```

Then update `callClaude()` in `src/renderer/utils.js` to point to `https://your-server.com/api/claude`.

---

## Troubleshooting

### `electron: command not found`
```bash
npm install electron --save-dev
```

### `react-scripts: command not found`
```bash
npm install react-scripts
```

### Blank white screen on launch
- Run `npm run dev` instead and check the browser console for errors
- Ensure `public/index.html` exists
- Check the Electron DevTools (`F12`) for renderer errors

### Build fails — `ENOENT: icon.ico`
Add a placeholder icon file:
```bash
# On Windows PowerShell:
New-Item assets/icon.ico
# Or copy any .ico file to assets/icon.ico
```

### App opens but AI features don't work
- The Claude API requires a valid API key
- Check the DevTools Network tab for failed requests to `api.anthropic.com`
- Confirm the `Content-Security-Policy` in `public/index.html` allows `connect-src https://api.anthropic.com`

---

## Distributing Your App

### Code Signing (Recommended for Windows)
Without a code signing certificate, Windows Defender SmartScreen will show a warning on first launch. To sign your app:

1. Purchase an **EV Code Signing Certificate** (DigiCert, Sectigo, etc.)
2. Add to `package.json`:
```json
"win": {
  "certificateFile": "path/to/cert.pfx",
  "certificatePassword": "your-password"
}
```

### Submit to Microsoft Store
Use `electron-builder`'s `appx` target:
```bash
npm run build -- --win appx
```

---

## Disclaimer

> This software is for **educational purposes only**.
> It is not financial advice. Trading involves significant risk of capital loss.
> Always thoroughly test any strategy before deploying with real funds.
> Past performance does not guarantee future results.

---

## License

MIT License · © 2025 Aegis-Trade
