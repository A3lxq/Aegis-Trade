// src/main/preload.js — Secure IPC bridge (contextBridge)
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // Window controls (custom titlebar)
  minimize:  () => ipcRenderer.send('window-minimize'),
  maximize:  () => ipcRenderer.send('window-maximize'),
  close:     () => ipcRenderer.send('window-close'),

  // Navigation from main menu keyboard shortcuts
  onNavigate: (callback) => ipcRenderer.on('navigate', (_event, screen) => callback(screen)),

  // Platform info
  platform:  process.platform,
  version:   process.env.npm_package_version || '2.5.0',
});
