// src/main/main.js  — Electron main process
const { app, BrowserWindow, Menu, shell, ipcMain, Tray, nativeImage } = require('electron');
const path  = require('path');
const isDev = require('electron-is-dev');

let mainWindow;
let tray = null;

function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1280,
    height: 820,
    minWidth:  1024,
    minHeight: 700,
    frame: false,          // custom titlebar
    titleBarStyle: 'hidden',
    backgroundColor: '#080c10',
    icon: path.join(__dirname, '../../assets/icon.ico'),
    webPreferences: {
      nodeIntegration:    false,
      contextIsolation:   true,
      preload:            path.join(__dirname, 'preload.js'),
    },
  });

  const startUrl = isDev
    ? 'http://localhost:3000'
    : `file://${path.join(__dirname, '../../build/index.html')}`;

  mainWindow.loadURL(startUrl);

  if (isDev) mainWindow.webContents.openDevTools();

  mainWindow.on('closed', () => { mainWindow = null; });

  // Prevent navigation to external URLs in main window
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

// ── Custom menu ──────────────────────────────────────────────────────────────
function buildMenu() {
  const template = [
    {
      label: 'Aegis-Trade',
      submenu: [
        { label: 'About', role: 'about' },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'CmdOrCtrl+Q', role: 'quit' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { label: 'Reload',         accelerator:'CmdOrCtrl+R',        role:'reload' },
        { label: 'Force Reload',   accelerator:'CmdOrCtrl+Shift+R',  role:'forceReload' },
        { label: 'Toggle DevTools',accelerator:'F12',                 role:'toggleDevTools' },
        { type: 'separator' },
        { label: 'Zoom In',        accelerator:'CmdOrCtrl+Plus',     role:'zoomIn' },
        { label: 'Zoom Out',       accelerator:'CmdOrCtrl+-',        role:'zoomOut' },
        { label: 'Reset Zoom',     accelerator:'CmdOrCtrl+0',        role:'resetZoom' },
        { type: 'separator' },
        { label: 'Toggle Fullscreen', accelerator:'F11', role:'togglefullscreen' },
      ],
    },
    {
      label: 'Trading',
      submenu: [
        { label: 'Dashboard',     accelerator:'CmdOrCtrl+1', click: () => mainWindow?.webContents.send('navigate','dashboard') },
        { label: 'Gold Scalper',  accelerator:'CmdOrCtrl+2', click: () => mainWindow?.webContents.send('navigate','gold') },
        { label: 'Strategies',    accelerator:'CmdOrCtrl+3', click: () => mainWindow?.webContents.send('navigate','strategy') },
        { label: 'Trade History', accelerator:'CmdOrCtrl+4', click: () => mainWindow?.webContents.send('navigate','history') },
        { label: 'AI Chat',       accelerator:'CmdOrCtrl+5', click: () => mainWindow?.webContents.send('navigate','ai') },
        { label: 'Connections',   accelerator:'CmdOrCtrl+6', click: () => mainWindow?.webContents.send('navigate','connect') },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ── Window control IPC ───────────────────────────────────────────────────────
ipcMain.on('window-minimize', () => mainWindow?.minimize());
ipcMain.on('window-maximize', () => {
  if (mainWindow?.isMaximized()) mainWindow.unmaximize();
  else mainWindow?.maximize();
});
ipcMain.on('window-close', () => mainWindow?.close());

// ── App lifecycle ────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  createWindow();
  buildMenu();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
