// src/renderer/App.jsx — Full Electron renderer with all screens
import React, { useState, useEffect, useRef, useCallback } from 'react';
import TitleBar  from './components/TitleBar';
import TickerBar from './components/TickerBar';
import { C, MOCK_SYMBOLS, MOCK_TRADES, HIST_TRADES, SCALP_SETUPS,
         generatePriceSeries, callClaude, card, cardHeader, btn, input, tag } from './utils';

/* ─── Global CSS ────────────────────────────────────────────────────────── */
const GLOBAL_CSS = `
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  body{background:#080c10;color:#e8f0fe;font-family:'DM Mono','Space Mono',monospace;overflow:hidden}
  ::-webkit-scrollbar{width:4px;height:4px}
  ::-webkit-scrollbar-track{background:#0d1117}
  ::-webkit-scrollbar-thumb{background:#253650;border-radius:2px}
  ::-webkit-scrollbar-thumb:hover{background:#00d4aa}
  @keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.35}}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes glowPulse{0%,100%{box-shadow:0 0 8px rgba(0,212,170,.2)}50%{box-shadow:0 0 24px rgba(0,212,170,.5)}}
  @keyframes goldGlow{0%,100%{box-shadow:0 0 8px rgba(255,215,0,.2)}50%{box-shadow:0 0 24px rgba(255,215,0,.5)}}
  .fadeUp{animation:fadeUp .35s ease both}
  .pulse{animation:pulse 2s infinite}
  input,select,textarea{outline:none}
  input::placeholder,textarea::placeholder{color:#4d6070}
  option{background:#0d1117}
  textarea{resize:vertical}
`;

/* ─── Tiny helpers ──────────────────────────────────────────────────────── */
const Spinner = ({ size=14 }) => (
  <div style={{ width:size, height:size, border:`2px solid #1e2d42`,
    borderTopColor:'#00d4aa', borderRadius:'50%', animation:'spin .7s linear infinite', flexShrink:0 }} />
);

function Sparkline({ data, w=120, h=34, color='#00d4aa' }) {
  const min=Math.min(...data), max=Math.max(...data), rng=max-min||1;
  const pts = data.map((v,i)=>`${(i/(data.length-1))*w},${h-((v-min)/rng)*h}`).join(' ');
  const id = `sg${color.replace(/[^a-z0-9]/gi,'')}`;
  return (
    <svg width={w} height={h} style={{overflow:'visible',display:'block'}}>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity=".25"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinejoin="round"/>
    </svg>
  );
}

/* ─── Live Mini Chart (SVG candlesticks) ────────────────────────────────── */
function LiveChart({ symbol }) {
  const base = symbol==='XAUUSD'?2341:symbol==='BTCUSD'?67500:symbol==='EURUSD'?1.0871:symbol==='NASDAQ'?18542:100;
  const [candles, setCandles] = useState(()=>Array.from({length:60},(_,i)=>{
    const o=base+(Math.random()-.5)*base*.006;
    const c=o+(Math.random()-.48)*base*.003;
    return{o,c,h:Math.max(o,c)+Math.random()*base*.002,l:Math.min(o,c)-Math.random()*base*.0015,t:i};
  }));
  useEffect(()=>{
    const iv=setInterval(()=>{
      setCandles(p=>{
        const last=p[p.length-1], o=last.c, delta=(Math.random()-.49)*base*.003;
        const c=o+delta;
        return[...p.slice(-59),{o,c,h:Math.max(o,c)+Math.random()*base*.001,l:Math.min(o,c)-Math.random()*base*.001,t:last.t+1}];
      });
    },900);
    return()=>clearInterval(iv);
  },[symbol]);

  const W=560,H=180;
  const all=candles.flatMap(c=>[c.h,c.l]);
  const mn=Math.min(...all)-.5,mx=Math.max(...all)+.5,rng=mx-mn;
  const toY=v=>H-((v-mn)/rng)*(H-20)-10;
  const cw=W/candles.length;

  const closes=candles.map(c=>c.c);
  const ema=(arr,p)=>{const k=2/(p+1),r=[arr[0]];for(let i=1;i<arr.length;i++)r.push(arr[i]*k+r[i-1]*(1-k));return r;};
  const e8=ema(closes,8),e21=ema(closes,21);
  const toPath=arr=>arr.map((v,i)=>`${i===0?'M':'L'}${i*cw+cw/2},${toY(v)}`).join(' ');

  const lastPt=candles[candles.length-1];
  const up=lastPt.c>=lastPt.o;

  return (
    <svg width="100%" viewBox={`0 0 ${W} ${H}`} style={{display:'block'}}>
      <defs>
        <linearGradient id="cg" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={up?C.accent:C.danger} stopOpacity=".18"/>
          <stop offset="100%" stopColor={up?C.accent:C.danger} stopOpacity="0"/>
        </linearGradient>
      </defs>
      {[0,1,2,3,4].map(i=>(
        <line key={i} x1="0" y1={10+i*(H-20)/4} x2={W} y2={10+i*(H-20)/4}
          stroke="#1e2d42" strokeWidth=".5" strokeDasharray="4,4"/>
      ))}
      {candles.map((c,i)=>{
        const x=i*cw+cw*.15,bw=cw*.7,up2=c.c>=c.o;
        const col=up2?C.accent:C.danger;
        const bTop=toY(Math.max(c.o,c.c)),bH=Math.abs(toY(c.o)-toY(c.c))||1;
        return(
          <g key={i}>
            <line x1={x+bw/2} y1={toY(c.h)} x2={x+bw/2} y2={toY(c.l)} stroke={col} strokeWidth=".8"/>
            <rect x={x} y={bTop} width={bw} height={bH} fill={col} opacity=".8"/>
          </g>
        );
      })}
      <path d={toPath(e8)}  fill="none" stroke="#ffd700" strokeWidth="1" opacity=".8"/>
      <path d={toPath(e21)} fill="none" stroke="#0099ff" strokeWidth="1" opacity=".8"/>
      {[0,1,2,3,4].map(i=>{
        const v=mn+(rng*(4-i)/4);
        return<text key={i} x={W-3} y={14+i*(H-20)/4} fill={C.text3} fontSize="8" textAnchor="end" fontFamily="Space Mono">{v>100?v.toFixed(0):v.toFixed(4)}</text>;
      })}
    </svg>
  );
}

/* ─── GOLD SCALPER SCREEN ───────────────────────────────────────────────── */
function GoldScalperScreen() {
  const [tab,setTab]           = useState('trade');
  const [autoScalp,setAuto]    = useState(false);
  const [lot,setLot]           = useState('0.10');
  const [sl,setSl]             = useState('8');
  const [tp,setTp]             = useState('12');
  const [aiSig,setAiSig]       = useState(null);
  const [loading,setLoading]   = useState(false);
  const [goldPrice,setGoldPrice]= useState(2341.50);
  const [goldChange,setChange]  = useState(+3.20);
  const [openTrades,setOpen]   = useState([
    {id:1,type:'BUY', entry:2339.80,current:2341.50,sl:2331.80,tp:2351.80,lots:.10,pnl:+17.0,time:'09:42'},
    {id:2,type:'SELL',entry:2344.20,current:2341.50,sl:2352.20,tp:2332.20,lots:.05,pnl:+13.5,time:'10:05'},
  ]);
  const [history,setHistory]   = useState([
    {id:10,type:'BUY', entry:2337.10,exit:2343.50,pips:'+6.4',pnl:+64.0,time:'08:31'},
    {id:11,type:'SELL',entry:2348.80,exit:2342.10,pips:'+6.7',pnl:+33.5,time:'08:47'},
    {id:12,type:'BUY', entry:2340.20,exit:2338.00,pips:'-2.2',pnl:-22.0,time:'09:15'},
    {id:13,type:'BUY', entry:2335.50,exit:2343.20,pips:'+7.7',pnl:+77.0,time:'09:28'},
  ]);
  const [activeSetup,setSetup] = useState(SCALP_SETUPS[0]);

  // Live gold price
  useEffect(()=>{
    const iv=setInterval(()=>{
      const d=(Math.random()-.49)*.8;
      setGoldPrice(p=>parseFloat((p+d).toFixed(2)));
      setChange(c=>parseFloat((c+d*.4).toFixed(2)));
      setOpen(prev=>prev.map(t=>{
        const nd=(Math.random()-.48)*.5, nc=parseFloat((t.current+nd).toFixed(2));
        const pip=t.type==='BUY'?nc-t.entry:t.entry-nc;
        return{...t,current:nc,pnl:parseFloat((pip*t.lots*100).toFixed(2))};
      }));
    },700);
    return()=>clearInterval(iv);
  },[]);

  const getSignal=async()=>{
    setLoading(true);setAiSig(null);
    try{
      const r=await callClaude(
        [{role:'user',content:`Generate a XAUUSD scalp signal near $${goldPrice}. Return ONLY JSON:{direction:"BUY"or"SELL",entry:number,sl:number,tp:number,tp2:number,confidence:number,sessionRating:string,reasoning:string,setupType:string,riskReward:string}`}],
        'Expert gold scalping trader. Return ONLY valid JSON with price levels near '+goldPrice+'.'
      );
      setAiSig(JSON.parse(r.replace(/```json|```/g,'').trim()));
    }catch{
      setAiSig({direction:'BUY',entry:goldPrice+.5,sl:goldPrice-8,tp:goldPrice+12,tp2:goldPrice+18,confidence:74,sessionRating:'Good',reasoning:'EMA 8 above EMA 21 on M5. RSI pulled back from 55 — momentum resuming with London volume.',setupType:'EMA Pullback Continuation',riskReward:'1:1.5'});
    }
    setLoading(false);
  };

  const placeOrder=(type)=>{
    const entry=parseFloat((goldPrice+(Math.random()-.5)*.3).toFixed(2));
    const s=parseFloat((type==='BUY'?entry-parseFloat(sl):entry+parseFloat(sl)).toFixed(2));
    const t=parseFloat((type==='BUY'?entry+parseFloat(tp):entry-parseFloat(tp)).toFixed(2));
    setOpen(p=>[...p,{id:Date.now(),type,entry,current:entry,sl:s,tp:t,lots:parseFloat(lot||.01),pnl:0,time:new Date().toTimeString().slice(0,5)}]);
  };

  const closeTrade=(id)=>{
    const t=openTrades.find(x=>x.id===id); if(!t)return;
    const pips=t.type==='BUY'?(t.current-t.entry).toFixed(1):(t.entry-t.current).toFixed(1);
    setHistory(p=>[{id:Date.now(),type:t.type,entry:t.entry,exit:t.current,pips:`${parseFloat(pips)>=0?'+':''}${pips}`,pnl:t.pnl,time:new Date().toTimeString().slice(0,5)},...p.slice(0,9)]);
    setOpen(p=>p.filter(x=>x.id!==id));
  };

  const dayPnl  = [...history,...openTrades].reduce((s,t)=>s+t.pnl,0);
  const winRate = history.length>0?((history.filter(t=>t.pnl>0).length/history.length)*100).toFixed(0):0;
  const up      = goldChange>=0;
  const rr      = (parseFloat(tp||1)/parseFloat(sl||1)).toFixed(1);
  const riskAmt = (parseFloat(lot||0)*parseFloat(sl||0)*10).toFixed(2);
  const rewAmt  = (parseFloat(lot||0)*parseFloat(tp||0)*10).toFixed(2);

  const SESSIONS=[
    {name:'Asian',   start:'01:00',end:'08:00',vol:'Low',      color:C.accent4},
    {name:'London',  start:'08:00',end:'12:00',vol:'High',     color:C.accent2},
    {name:'NY Open', start:'13:00',end:'16:00',vol:'Very High',color:C.accent },
    {name:'Overlap', start:'13:00',end:'15:00',vol:'Extreme',  color:C.accent3},
  ];

  const NEWS=[
    {time:'14:30',event:'US CPI Data',     impact:'High',col:C.danger},
    {time:'16:00',event:'Fed Chair Speech',impact:'High',col:C.danger},
    {time:'18:00',event:'Crude Inventories',impact:'Med',col:C.accent3},
  ];

  const s={
    cont:{display:'flex',flexDirection:'column',gap:12,animation:'fadeUp .35s ease'},
    goldBanner:{background:'linear-gradient(135deg,#1a1200 0%,#0d1117 40%,#0a1020 100%)',border:'1px solid rgba(255,215,0,0.22)',borderRadius:12,padding:'14px 18px',display:'flex',gap:16,alignItems:'center',position:'relative',overflow:'hidden'},
    goldTitle:{fontFamily:'Syne,sans-serif',fontWeight:800,fontSize:14,color:C.gold,letterSpacing:'-.01em',marginBottom:3},
    priceNum:{fontFamily:'Syne,sans-serif',fontWeight:800,fontSize:28,color:up?C.accent:C.danger,transition:'color .3s',lineHeight:1.1},
    sessionBadge:(s2)=>({flex:1,padding:'7px 10px',borderRadius:8,border:`1px solid ${s2.color}40`,background:s2.color+'0d',textAlign:'center'}),
    tabBtn:(t)=>({padding:'7px 16px',border:'none',background:'none',cursor:'pointer',color:tab===t?C.gold:C.text2,borderBottom:tab===t?`2px solid ${C.gold}`:'2px solid transparent',fontFamily:'Space Mono,monospace',fontSize:10,textTransform:'uppercase',letterSpacing:'.08em',marginBottom:'-1px',transition:'all .2s'}),
    orderBtn:(type)=>({flex:1,padding:14,border:`1px solid ${type==='BUY'?C.accent:C.danger}`,borderRadius:8,background:type==='BUY'?'rgba(0,212,170,.12)':'rgba(255,69,96,.12)',cursor:'pointer',fontSize:14,fontWeight:700,fontFamily:'Space Mono,monospace',color:type==='BUY'?C.accent:C.danger}),
    goldBtn:{width:'100%',padding:13,background:`linear-gradient(135deg,${C.goldDark},${C.gold})`,border:`1px solid ${C.gold}`,borderRadius:8,cursor:'pointer',color:'#000',fontFamily:'Space Mono,monospace',fontWeight:900,fontSize:12,display:'flex',alignItems:'center',justifyContent:'center',gap:8},
  };

  return (
    <div style={s.cont}>
      {/* Gold price banner */}
      <div style={s.goldBanner}>
        <div style={{position:'absolute',inset:0,background:'radial-gradient(ellipse at 0% 50%,rgba(255,215,0,.06) 0%,transparent 60%)',pointerEvents:'none'}}/>
        <div style={{fontSize:36}}>🥇</div>
        <div style={{flex:1}}>
          <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
            <span style={s.goldTitle}>XAUUSD · GOLD SCALPER</span>
            <span style={tag('gold')}>⚡ AI-POWERED</span>
            {autoScalp&&<span style={{...tag('green'),animation:'glowPulse 1.5s infinite'}}>🤖 SCANNING</span>}
          </div>
          <div style={s.priceNum}>{goldPrice.toFixed(2)}</div>
          <div style={{fontSize:11,color:up?C.accent:C.danger,fontFamily:'Space Mono,monospace',marginTop:2}}>
            {up?'▲':'▼'} {Math.abs(goldChange).toFixed(2)} ({up?'+':''}{(goldChange/(goldPrice-goldChange)*100).toFixed(2)}%)
            &nbsp;&nbsp;BID: <span style={{color:C.danger}}>{(goldPrice-.20).toFixed(2)}</span>
            &nbsp;ASK: <span style={{color:C.accent}}>{(goldPrice+.20).toFixed(2)}</span>
            &nbsp;SPREAD: 0.40
          </div>
        </div>
        {/* Stats */}
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7}}>
          {[['Day P&L',`${dayPnl>=0?'+':''}$${dayPnl.toFixed(2)}`,dayPnl>=0?C.accent:C.danger],
            ['Win Rate',`${winRate}%`,parseInt(winRate)>=60?C.accent:C.accent3],
            ['Open',`${openTrades.length} trades`,C.text2],
            ['Closed',`${history.length}`,C.text2]
          ].map(([l,v,c])=>(
            <div key={l} style={{background:'rgba(0,0,0,.3)',borderRadius:6,padding:'6px 10px',textAlign:'center'}}>
              <div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div>
              <div style={{fontSize:13,fontFamily:'Syne,sans-serif',fontWeight:800,color:c,marginTop:1}}>{v}</div>
            </div>
          ))}
        </div>
        {/* Auto-scalp toggle */}
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:6}}>
          <span style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>Auto Scalp</span>
          <button onClick={()=>setAuto(v=>!v)} style={{width:38,height:22,borderRadius:11,background:autoScalp?C.accent:C.border2,border:'none',cursor:'pointer',position:'relative',transition:'background .2s'}}>
            <div style={{position:'absolute',width:16,height:16,borderRadius:'50%',background:'#fff',top:3,left:autoScalp?19:3,transition:'left .2s'}}/>
          </button>
        </div>
      </div>

      {/* Sessions */}
      <div style={{display:'flex',gap:8}}>
        {SESSIONS.map(sess=>(
          <div key={sess.name} style={s.sessionBadge(sess)}>
            <div style={{fontSize:9,color:sess.color,fontFamily:'Space Mono,monospace',fontWeight:700}}>{sess.name}</div>
            <div style={{fontSize:8,color:C.text3}}>{sess.start}–{sess.end} UTC</div>
            <div style={{fontSize:8,color:sess.color,marginTop:1}}>{sess.vol}</div>
          </div>
        ))}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 320px',gap:12}}>
        {/* Left: Chart + indicators + trade panel */}
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {/* Chart */}
          <div style={card()}>
            <div style={cardHeader()}>
              <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.gold,textTransform:'uppercase',letterSpacing:'.1em'}}>XAUUSD · M5 Chart</span>
              <div style={{display:'flex',gap:8,alignItems:'center',fontSize:9,fontFamily:'Space Mono,monospace',color:C.text3}}>
                {[['EMA 8',C.gold],['EMA 21',C.accent2]].map(([l,c])=>(
                  <span key={l} style={{display:'flex',alignItems:'center',gap:4}}>
                    <span style={{width:14,height:2,background:c,display:'inline-block',borderRadius:1}}/>
                    {l}
                  </span>
                ))}
              </div>
            </div>
            <div style={{padding:'10px 14px'}}><LiveChart symbol="XAUUSD"/></div>
            {/* Indicator row */}
            <div style={{display:'flex',gap:8,padding:'0 14px 14px'}}>
              {[['RSI(14)','48','Neutral',C.text2],['MACD','▲ Bull','Cross',C.accent],['EMA Trend','8>21','Bullish',C.accent],['ATR(14)','2.84','Vol',C.accent3],['Volume','+28%','High',C.accent2]].map(([l,v,s2,c])=>(
                <div key={l} style={{flex:1,background:C.bg2,borderRadius:6,padding:'6px 8px'}}>
                  <div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div>
                  <div style={{fontSize:11,color:c,fontFamily:'Space Mono,monospace',fontWeight:700,marginTop:2}}>{v}</div>
                  <div style={{fontSize:8,color:C.text3}}>{s2}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Tabs */}
          <div style={{borderBottom:`1px solid ${C.border}`,display:'flex'}}>
            {[['trade','Quick Trade'],['setups','Setups'],['news','News']].map(([t,l])=>(
              <button key={t} onClick={()=>setTab(t)} style={s.tabBtn(t)}>{l}</button>
            ))}
          </div>

          {tab==='trade'&&(
            <div style={card()}>
              <div style={cardHeader()}><span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Quick Scalp Order</span></div>
              <div style={{padding:14,display:'flex',flexDirection:'column',gap:12}}>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:10}}>
                  {[['Lot Size',lot,setLot,'0.01–1.0'],['SL (pips)',sl,setSl,'5–20'],['TP (pips)',tp,setTp,'8–30']].map(([l,v,sv,hint])=>(
                    <div key={l}>
                      <div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace',marginBottom:4}}>{l} <span style={{fontSize:7,color:C.text3}}>({hint})</span></div>
                      <input style={{...input(),padding:'8px 10px',textAlign:'center'}} value={v} onChange={e=>sv(e.target.value)}/>
                    </div>
                  ))}
                </div>
                <div style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace',textAlign:'center'}}>
                  Risk: ~${riskAmt} · Reward: ~${rewAmt} · RR 1:{rr}
                </div>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
                  <button onClick={()=>placeOrder('BUY')}  style={s.orderBtn('BUY')}>▲ BUY GOLD</button>
                  <button onClick={()=>placeOrder('SELL')} style={s.orderBtn('SELL')}>▼ SELL GOLD</button>
                </div>
              </div>
            </div>
          )}

          {tab==='setups'&&(
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              {SCALP_SETUPS.map(ss=>(
                <div key={ss.id} onClick={()=>setSetup(ss)} style={{...card(),padding:14,cursor:'pointer',border:activeSetup.id===ss.id?`1px solid ${C.gold}50`:`1px solid ${C.border}`,background:activeSetup.id===ss.id?`${C.gold}06`:C.surface}}>
                  <div style={{display:'flex',alignItems:'center',gap:12}}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:4}}>
                        <span style={{fontFamily:'Syne,sans-serif',fontWeight:700,fontSize:13}}>{ss.name}</span>
                        <span style={tag('blue')}>{ss.tf}</span>
                        <span style={tag(ss.risk==='Low'?'green':ss.risk==='Medium'?'orange':'red')}>{ss.risk} Risk</span>
                      </div>
                      <span style={{fontSize:11,color:C.text2}}>{ss.desc}</span>
                    </div>
                    <div style={{textAlign:'center',flexShrink:0}}>
                      <div style={{fontSize:8,color:C.text3,textTransform:'uppercase'}}>Win Rate</div>
                      <div style={{fontSize:20,fontFamily:'Syne,sans-serif',fontWeight:800,color:ss.winRate>=68?C.accent:C.accent3}}>{ss.winRate}%</div>
                      <div style={{fontSize:8,color:C.text3}}>avg +{ss.avgPips} pips</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {tab==='news'&&(
            <div style={card()}>
              <div style={cardHeader()}><span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Gold-Impacting Events</span></div>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:11,fontFamily:'Space Mono,monospace'}}>
                <thead><tr style={{borderBottom:`1px solid ${C.border}`}}>
                  {['Time (UTC)','Event','Impact'].map(h=>(
                    <th key={h} style={{padding:'8px 14px',textAlign:'left',color:C.text3,fontWeight:400,fontSize:9,textTransform:'uppercase'}}>{h}</th>
                  ))}
                </tr></thead>
                <tbody>{NEWS.map((n,i)=>(
                  <tr key={i} style={{borderBottom:`1px solid ${C.border}`}}>
                    <td style={{padding:'10px 14px',color:C.gold}}>{n.time}</td>
                    <td style={{fontWeight:700}}>{n.event}</td>
                    <td><span style={{...tag(n.impact==='High'?'red':'orange')}}>{n.impact}</span></td>
                  </tr>
                ))}</tbody>
              </table>
              <div style={{padding:'10px 14px',fontSize:10,color:C.accent3,borderTop:`1px solid ${C.border}`}}>⚠ Auto-scalping pauses 5 min before high-impact news.</div>
            </div>
          )}
        </div>

        {/* Right: AI Signal + trades */}
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {/* AI Signal card */}
          <div style={{background:`linear-gradient(180deg,${C.gold}06 0%,${C.surface} 100%)`,border:`1px solid ${C.gold}30`,borderRadius:10,overflow:'hidden'}}>
            <div style={{...cardHeader(),background:`${C.gold}08`}}>
              <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.gold,textTransform:'uppercase',letterSpacing:'.1em'}}>⚡ AI Scalp Signal</span>
              <span style={{fontSize:8,color:C.text3,fontFamily:'Space Mono,monospace'}}>Claude AI</span>
            </div>
            <div style={{padding:14,display:'flex',flexDirection:'column',gap:10}}>
              <button onClick={getSignal} disabled={loading} style={{...s.goldBtn,opacity:loading?.7:1}}>
                {loading?<><Spinner/>&nbsp;Analyzing Gold...</>:<>🥇&nbsp;GET GOLD SCALP SIGNAL</>}
              </button>
              {loading&&(
                <div style={{textAlign:'center',padding:8}}>
                  <div style={{fontSize:9,color:C.text3,marginBottom:4}}>Analyzing M1/M5 structure...</div>
                  <div style={{height:3,background:C.border,borderRadius:2,overflow:'hidden'}}>
                    <div style={{height:'100%',width:'70%',background:C.gold,borderRadius:2,animation:'pulse 1s infinite'}}/>
                  </div>
                </div>
              )}
              {aiSig&&!loading&&(
                <div style={{animation:'fadeUp .3s ease',display:'flex',flexDirection:'column',gap:9}}>
                  <div style={{display:'flex',alignItems:'center',gap:10,padding:'9px 12px',borderRadius:8,background:aiSig.direction==='BUY'?'rgba(0,212,170,.1)':'rgba(255,69,96,.1)',border:`1px solid ${aiSig.direction==='BUY'?C.accent:C.danger}40`}}>
                    <span style={{fontSize:20,fontFamily:'Syne,sans-serif',fontWeight:900,color:aiSig.direction==='BUY'?C.accent:C.danger}}>{aiSig.direction==='BUY'?'▲ BUY':'▼ SELL'}</span>
                    <div>
                      <div style={{fontSize:8,color:C.text3}}>SETUP</div>
                      <div style={{fontSize:10,color:C.text,fontFamily:'Space Mono,monospace'}}>{aiSig.setupType}</div>
                    </div>
                    <div style={{marginLeft:'auto',textAlign:'right'}}>
                      <div style={{fontSize:8,color:C.text3}}>SESSION</div>
                      <div style={{fontSize:10,color:C.accent,fontFamily:'Space Mono,monospace'}}>{aiSig.sessionRating}</div>
                    </div>
                  </div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7}}>
                    {[['Entry',aiSig.entry,C.text],['Stop Loss',aiSig.sl,C.danger],['TP 1',aiSig.tp,C.accent],['TP 2',aiSig.tp2,C.gold]].map(([l,v,c])=>(
                      <div key={l} style={{background:C.bg2,borderRadius:7,padding:'7px 10px'}}>
                        <div style={{fontSize:7,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div>
                        <div style={{fontSize:14,fontFamily:'Space Mono,monospace',fontWeight:700,color:c,marginTop:2}}>{typeof v==='number'?v.toFixed(2):v}</div>
                      </div>
                    ))}
                  </div>
                  <div>
                    <div style={{display:'flex',justifyContent:'space-between',marginBottom:3}}>
                      <span style={{fontSize:8,color:C.text3,textTransform:'uppercase'}}>Confidence</span>
                      <span style={{fontSize:9,color:aiSig.confidence>70?C.accent:C.accent3,fontFamily:'Space Mono,monospace'}}>{aiSig.confidence}%</span>
                    </div>
                    <div style={{height:4,background:C.border,borderRadius:2,overflow:'hidden'}}>
                      <div style={{height:'100%',width:`${aiSig.confidence}%`,background:aiSig.confidence>70?C.accent:C.gold,borderRadius:2,transition:'width .5s'}}/>
                    </div>
                  </div>
                  <div style={{background:C.bg2,borderRadius:7,padding:'8px 10px'}}>
                    <p style={{fontSize:10,color:C.text2,fontFamily:'Space Mono,monospace',lineHeight:1.6}}>{aiSig.reasoning}</p>
                  </div>
                  <div style={{display:'flex',gap:8}}>
                    <button onClick={()=>placeOrder(aiSig.direction)} style={{flex:1,padding:10,border:`1px solid ${aiSig.direction==='BUY'?C.accent:C.danger}`,borderRadius:7,background:aiSig.direction==='BUY'?'rgba(0,212,170,.12)':'rgba(255,69,96,.12)',cursor:'pointer',color:aiSig.direction==='BUY'?C.accent:C.danger,fontFamily:'Space Mono,monospace',fontWeight:700,fontSize:11}}>
                      ▶ Execute in MT5
                    </button>
                  </div>
                </div>
              )}
              {!aiSig&&!loading&&(
                <div style={{textAlign:'center',padding:16,opacity:.5}}>
                  <div style={{fontSize:28,marginBottom:6}}>🥇</div>
                  <div style={{fontSize:10,color:C.text2}}>Click above for AI gold scalp signal</div>
                </div>
              )}
            </div>
          </div>

          {/* Open trades */}
          <div style={card()}>
            <div style={cardHeader()}>
              <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Open Scalp Trades</span>
              <span style={{fontSize:10,color:openTrades.length>0?C.accent:C.text3,fontFamily:'Space Mono,monospace'}}>{openTrades.length} active</span>
            </div>
            {openTrades.length===0&&<div style={{padding:14,textAlign:'center',fontSize:10,color:C.text3}}>No open trades</div>}
            {openTrades.map(t=>{
              const rng=Math.abs(t.tp-t.entry)||1;
              const prog=Math.max(0,Math.min(100,(t.type==='BUY'?(t.current-t.entry)/rng:(t.entry-t.current)/rng)*100));
              return(
                <div key={t.id} style={{padding:'9px 13px',borderBottom:`1px solid ${C.border}`,display:'flex',flexDirection:'column',gap:5}}>
                  <div style={{display:'flex',alignItems:'center',gap:8}}>
                    <span style={tag(t.type==='BUY'?'green':'red')}>{t.type}</span>
                    <span style={{fontSize:10,color:C.text2,fontFamily:'Space Mono,monospace'}}>@{t.entry.toFixed(2)} → {t.current.toFixed(2)}</span>
                    <span style={{marginLeft:'auto',fontSize:12,fontFamily:'Space Mono,monospace',fontWeight:700,color:t.pnl>=0?C.accent:C.danger}}>
                      {t.pnl>=0?'+':''}${t.pnl.toFixed(2)}
                    </span>
                  </div>
                  <div style={{display:'flex',gap:10,fontSize:8,color:C.text3,fontFamily:'Space Mono,monospace'}}>
                    <span>SL: <span style={{color:C.danger}}>{t.sl.toFixed(2)}</span></span>
                    <span>TP: <span style={{color:C.accent}}>{t.tp.toFixed(2)}</span></span>
                    <span>Lots: {t.lots}</span>
                    <button onClick={()=>closeTrade(t.id)} style={{marginLeft:'auto',padding:'2px 8px',border:`1px solid ${C.danger}`,borderRadius:4,background:'none',color:C.danger,cursor:'pointer',fontSize:9,fontFamily:'Space Mono,monospace'}}>Close</button>
                  </div>
                  <div style={{height:3,background:C.border,borderRadius:2,overflow:'hidden'}}>
                    <div style={{height:'100%',width:`${prog}%`,background:prog>0?C.accent:C.danger,borderRadius:2}}/>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Scalp history */}
          <div style={card()}>
            <div style={cardHeader()}>
              <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Today's Scalps</span>
              <span style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace'}}>{history.length} trades</span>
            </div>
            <div style={{maxHeight:200,overflowY:'auto'}}>
              {history.map(t=>(
                <div key={t.id} style={{padding:'7px 13px',borderBottom:`1px solid ${C.border}`,display:'flex',alignItems:'center',gap:8}}>
                  <span style={tag(t.type==='BUY'?'green':'red')}>{t.type}</span>
                  <span style={{fontSize:9,color:C.text2,fontFamily:'Space Mono,monospace'}}>{t.entry}→{t.exit}</span>
                  <span style={{fontSize:9,fontFamily:'Space Mono,monospace',color:parseFloat(t.pips)>=0?C.accent:C.danger}}>{t.pips}p</span>
                  <span style={{marginLeft:'auto',fontSize:10,fontFamily:'Space Mono,monospace',fontWeight:700,color:t.pnl>=0?C.accent:C.danger}}>{t.pnl>=0?'+':''}${t.pnl.toFixed(2)}</span>
                  <span style={{fontSize:8,color:C.text3}}>{t.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── DASHBOARD SCREEN ──────────────────────────────────────────────────── */
function DashboardScreen({tvConnected,mt5Connected,setScreen}) {
  const [prices]    = useState(()=>Object.fromEntries(MOCK_SYMBOLS.map(s=>[s,generatePriceSeries(Math.random()*100+1,30)])));
  const [sel,setSel]= useState('EURUSD');
  const [aiSig,setAiSig]=useState(null);
  const [loading,setLoading]=useState(false);
  const [autoTrade,setAuto]=useState(false);
  const [trades,setTrades]=useState(MOCK_TRADES);

  useEffect(()=>{
    const iv=setInterval(()=>setTrades(p=>p.map(t=>{
      const d=(Math.random()-.48)*.5,nc=parseFloat((t.current+d).toFixed(4));
      const pip=t.type==='BUY'?nc-t.entry:t.entry-nc;
      return{...t,current:nc,pnl:parseFloat((pip*t.lots*(t.symbol==='XAUUSD'?100:10000)).toFixed(2)),pnlPct:parseFloat((pip/t.entry*100).toFixed(2))};
    })),800);
    return()=>clearInterval(iv);
  },[]);

  const getSignal=async()=>{
    setLoading(true);setAiSig(null);
    try{
      const r=await callClaude([{role:'user',content:`EURUSD signal JSON:{signal:"BUY"or"SELL"or"HOLD",entry,sl,tp,confidence,reasoning(2 sentences max)}`}],'Expert forex trader. ONLY valid JSON.');
      setAiSig(JSON.parse(r.replace(/```json|```/g,'').trim()));
    }catch{setAiSig({signal:'HOLD',entry:'1.0871',sl:'1.0830',tp:'1.0920',confidence:58,reasoning:'Market in consolidation. Wait for clearer breakout before entering.'});}
    setLoading(false);
  };

  const totalPnL=trades.reduce((s,t)=>s+t.pnl,0);

  return(
    <div style={{display:'flex',flexDirection:'column',gap:14,animation:'fadeUp .35s ease'}}>
      {(!tvConnected||!mt5Connected)&&(
        <div style={{padding:'9px 14px',background:'rgba(255,107,53,.07)',border:'1px solid rgba(255,107,53,.25)',borderRadius:8,display:'flex',alignItems:'center',gap:10}}>
          <span style={{fontSize:13}}>⚠️</span>
          <span style={{fontSize:11,color:C.accent3}}>
            {!tvConnected&&!mt5Connected?'Connect TradingView and MetaTrader 5 to enable autonomous trading.':!tvConnected?'Connect TradingView for chart data.':'Connect MetaTrader 5 to execute trades.'}
            {' '}<span style={{textDecoration:'underline',cursor:'pointer',color:C.accent}} onClick={()=>setScreen('connect')}>Set up →</span>
          </span>
        </div>
      )}

      {/* Stats */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12}}>
        {[['Account Balance','$12,847.50','+$237 today',C.accent],['Open Trades','4','2 BUY · 2 SELL',C.accent2],['Daily P&L','+$237.00','+1.88%',C.accent],['Win Rate (30d)','71.4%','15/21 trades',C.accent4]].map(([l,v,sub,c])=>(
          <div key={l} style={{...card(),padding:16}}>
            <div style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace',textTransform:'uppercase',letterSpacing:'.08em',marginBottom:5}}>{l}</div>
            <div style={{fontSize:22,fontFamily:'Syne,sans-serif',fontWeight:800,color:c}}>{v}</div>
            <div style={{fontSize:9,color:C.text2,marginTop:3}}>{sub}</div>
          </div>
        ))}
      </div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 300px',gap:12}}>
        {/* Chart */}
        <div style={card()}>
          <div style={cardHeader()}>
            <div style={{display:'flex',alignItems:'center',gap:10}}>
              <select style={{...input(),width:120,padding:'4px 8px'}} value={sel} onChange={e=>setSel(e.target.value)}>
                {MOCK_SYMBOLS.map(s=><option key={s}>{s}</option>)}
              </select>
              <span style={tag('blue')}>1H</span>
            </div>
            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              <button onClick={getSignal} disabled={loading} style={{...btn(),borderColor:loading?C.border:C.accent,color:loading?C.text2:C.accent}}>
                {loading?<Spinner/>:'⚡'} AI Signal
              </button>
              <div style={{display:'flex',alignItems:'center',gap:6}}>
                <span style={{fontSize:9,color:C.text2,fontFamily:'Space Mono,monospace'}}>Auto-Trade</span>
                <button onClick={()=>setAuto(v=>!v)} style={{width:36,height:20,borderRadius:10,background:autoTrade?C.accent:C.border2,border:'none',cursor:'pointer',position:'relative',transition:'background .2s'}}>
                  <div style={{position:'absolute',width:14,height:14,borderRadius:'50%',background:'#fff',top:3,left:autoTrade?19:3,transition:'left .2s'}}/>
                </button>
              </div>
            </div>
          </div>
          <div style={{padding:'10px 14px'}}><LiveChart symbol={sel}/></div>
          {aiSig&&(
            <div style={{margin:'0 14px 14px',padding:11,background:C.bg2,borderRadius:8,border:`1px solid ${aiSig.signal==='BUY'?'rgba(0,212,170,.3)':aiSig.signal==='SELL'?'rgba(255,69,96,.3)':C.border}`}}>
              <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:7}}>
                <span style={tag(aiSig.signal==='BUY'?'green':aiSig.signal==='SELL'?'red':'blue')}>{aiSig.signal}</span>
                <span style={{fontSize:9,color:C.text2,fontFamily:'Space Mono,monospace'}}>Confidence: <b style={{color:aiSig.confidence>70?C.accent:C.text}}>{aiSig.confidence}%</b></span>
                <div style={{flex:1,height:3,background:C.border,borderRadius:2,overflow:'hidden'}}>
                  <div style={{height:'100%',width:`${aiSig.confidence}%`,background:aiSig.confidence>70?C.accent:C.accent3,borderRadius:2}}/>
                </div>
              </div>
              <div style={{display:'flex',gap:14,marginBottom:7}}>
                {[['Entry',aiSig.entry],['SL',aiSig.sl],['TP',aiSig.tp]].map(([l,v])=>(
                  <div key={l}><div style={{fontSize:8,color:C.text3,textTransform:'uppercase'}}>{l}</div><div style={{fontSize:11,fontFamily:'Space Mono,monospace',color:C.text}}>{v}</div></div>
                ))}
              </div>
              <p style={{fontSize:10,color:C.text2,lineHeight:1.55,fontFamily:'Space Mono,monospace'}}>{aiSig.reasoning}</p>
              {autoTrade&&<div style={{marginTop:7}}><span style={{...tag('green'),animation:'glowPulse 2s infinite'}}>⚡ Auto-executing in MT5...</span></div>}
            </div>
          )}
        </div>

        {/* Right panel */}
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          <div style={card()}>
            <div style={cardHeader()}>
              <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Equity Curve</span>
              <span style={tag('green')}>+21.0%</span>
            </div>
            <div style={{padding:'10px 14px'}}>
              <Sparkline data={[10000,10120,10085,10340,10280,10510,10490,10720,10680,10850,11020,10980,11200,11350,11580,11720,11850,12100]} w={240} h={52}/>
            </div>
          </div>
          <div style={{...card(),flex:1}}>
            <div style={cardHeader()}><span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Market Scanner</span></div>
            <div style={{overflowY:'auto',maxHeight:220}}>
              {MOCK_SYMBOLS.map(sym=>{
                const p=prices[sym],last=p[p.length-1],prev=p[p.length-5];
                const chg=((last-prev)/prev*100).toFixed(2),up2=parseFloat(chg)>=0;
                return(
                  <div key={sym} onClick={()=>setSel(sym)} style={{display:'flex',alignItems:'center',padding:'7px 13px',cursor:'pointer',borderBottom:`1px solid ${C.border}`,background:sel===sym?C.surface2:'transparent',transition:'background .15s'}}>
                    <div style={{flex:1}}>
                      <div style={{fontSize:11,fontFamily:'Syne,sans-serif',fontWeight:700}}>{sym}</div>
                      <div style={{fontSize:9,color:up2?C.accent:C.danger}}>{up2?'▲':'▼'} {Math.abs(parseFloat(chg))}%</div>
                    </div>
                    <Sparkline data={p.slice(-20)} w={56} h={20} color={up2?C.accent:C.danger}/>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Positions table */}
      <div style={card()}>
        <div style={cardHeader()}>
          <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Open Positions · MT5</span>
          <div style={{display:'flex',gap:6,alignItems:'center'}}>
            <div style={{width:6,height:6,borderRadius:'50%',background:C.accent,animation:'pulse 2s infinite'}}/>
            <span style={{fontSize:9,color:C.text2,fontFamily:'Space Mono,monospace'}}>Live</span>
          </div>
        </div>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:11,fontFamily:'Space Mono,monospace'}}>
            <thead>
              <tr style={{borderBottom:`1px solid ${C.border}`}}>
                {['Symbol','Type','Entry','Current','SL','TP','Lots','P&L','Time','Action'].map(h=>(
                  <th key={h} style={{padding:'8px 12px',textAlign:'left',color:C.text3,fontWeight:400,fontSize:9,textTransform:'uppercase',letterSpacing:'.05em'}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {trades.map(t=>(
                <tr key={t.id} style={{borderBottom:`1px solid ${C.border}`}}>
                  <td style={{padding:'9px 12px',fontWeight:700}}>{t.symbol}</td>
                  <td><span style={tag(t.type==='BUY'?'green':'red')}>{t.type}</span></td>
                  <td style={{color:C.text2}}>{t.entry}</td>
                  <td style={{color:t.pnl>0?C.accent:C.danger}}>{typeof t.current==='number'?t.current.toFixed(4):t.current}</td>
                  <td style={{color:C.danger}}>{t.sl}</td>
                  <td style={{color:C.accent}}>{t.tp}</td>
                  <td style={{color:C.text2}}>{t.lots}</td>
                  <td style={{fontWeight:700,color:t.pnl>0?C.accent:C.danger}}>{t.pnl>0?'+':''}${t.pnl.toFixed(2)}</td>
                  <td style={{color:C.text3}}>{t.time}</td>
                  <td><button style={{padding:'3px 8px',border:`1px solid ${C.danger}`,borderRadius:4,background:'none',color:C.danger,cursor:'pointer',fontSize:9,fontFamily:'Space Mono,monospace'}}>Close</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div style={{padding:'7px 12px',borderTop:`1px solid ${C.border}`,display:'flex',justifyContent:'flex-end',gap:14}}>
          <span style={{fontSize:10,color:C.text2,fontFamily:'Space Mono,monospace'}}>Total P&L:</span>
          <span style={{fontSize:12,fontFamily:'Space Mono,monospace',fontWeight:700,color:totalPnL>0?C.accent:C.danger}}>{totalPnL>0?'+':''}${totalPnL.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}

/* ─── STRATEGY SCREEN (abbreviated for space) ───────────────────────────── */
function StrategyScreen() {
  const [name,setName]=useState('');
  const [text,setText]=useState('');
  const [insight,setInsight]=useState(null);
  const [loading,setLoading]=useState(false);
  const [btRunning,setBtRunning]=useState(false);
  const [btResult,setBtResult]=useState(null);

  const getInsight=async()=>{
    if(!text.trim())return;
    setLoading(true);setInsight(null);
    try{
      const r=await callClaude([{role:'user',content:`Analyze this trading strategy:\n${text}\nReturn JSON:{strengths:[],weaknesses:[],bestMarkets:string,riskLevel:string,improvements:[],rating:number,summary:string}`}],'Quant trading analyst. ONLY valid JSON.');
      setInsight(JSON.parse(r.replace(/```json|```/g,'').trim()));
    }catch{setInsight({strengths:['Clear rules'],weaknesses:['Needs more detail'],bestMarkets:'Forex majors',riskLevel:'Medium',improvements:['Add time filter','Define position sizing'],rating:6,summary:'Strategy shows promise with well-defined entry rules. Consider adding volume confirmation and session filters.'});}
    setLoading(false);
  };

  const runBacktest=()=>{
    setBtRunning(true);setBtResult(null);
    setTimeout(()=>{
      setBtRunning(false);
      setBtResult({trades:147,winRate:64.6,pf:1.92,profit:3847,dd:-8.4,sharpe:1.74,equity:generatePriceSeries(10000,40)});
    },2800);
  };

  const TEMPLATES=[
    {name:'EMA Crossover',text:'Entry: EMA(9) crosses above EMA(21) on H1\nFilter: RSI(14) > 50\nStop Loss: 20 pips\nTake Profit: 40 pips (1:2 RR)\nTime: London + NY sessions only\nMax trades: 3/day'},
    {name:'RSI Reversal', text:'Long: RSI(14) < 30 at support zone\nShort: RSI(14) > 70 at resistance zone\nConfirmation: Engulfing candle\nSL: Beyond swing high/low\nTP: 1:2.5 RR'},
    {name:'Gold Breakout', text:'Symbol: XAUUSD\nSetup: 30-min London range identification\nEntry: Break of range high/low with volume\nSL: Opposite side of range\nTP: 1x range extension\nSession: London open 08:00-09:30 UTC'},
  ];

  return(
    <div style={{display:'flex',flexDirection:'column',gap:14,animation:'fadeUp .35s ease'}}>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          <div style={card()}>
            <div style={cardHeader()}><span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Strategy Editor</span></div>
            <div style={{padding:14,display:'flex',flexDirection:'column',gap:10}}>
              <input style={input()} placeholder="Strategy name..." value={name} onChange={e=>setName(e.target.value)}/>
              <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                {TEMPLATES.map(t=>(
                  <button key={t.name} onClick={()=>{setName(t.name);setText(t.text);}} style={btn({fontSize:9})}>{t.name}</button>
                ))}
              </div>
              <textarea style={{...input(),minHeight:180,lineHeight:'1.6',fontFamily:'Space Mono,monospace',fontSize:11}} placeholder="Describe your strategy in plain English..." value={text} onChange={e=>setText(e.target.value)}/>
              <div style={{display:'flex',gap:8}}>
                <button onClick={getInsight} disabled={loading||!text.trim()} style={{flex:1,padding:10,background:C.accent,border:'none',borderRadius:6,color:'#000',fontFamily:'Space Mono,monospace',fontWeight:900,fontSize:11,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6,opacity:loading||!text.trim()?.6:1}}>
                  {loading?<><Spinner size={12}/> Analyzing...</>:'⚡ Get AI Insights'}
                </button>
                <button style={btn({padding:'9px 14px'})} onClick={()=>{}}>Save</button>
              </div>
            </div>
          </div>
          {insight&&(
            <div style={card()}>
              <div style={cardHeader()}>
                <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Backtest Config</span>
              </div>
              <div style={{padding:14,display:'flex',flexDirection:'column',gap:9}}>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:9}}>
                  {[['Symbol','EURUSD'],['Timeframe','H1'],['From','2023-01-01'],['To','2024-12-31'],['Balance','$10,000'],['Risk/Trade','1%']].map(([l,d])=>(
                    <div key={l}><div style={{fontSize:8,color:C.text3,marginBottom:3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div><input style={{...input(),padding:'6px 9px'}} defaultValue={d}/></div>
                  ))}
                </div>
                <button onClick={runBacktest} disabled={btRunning} style={{padding:10,background:btRunning?C.surface:C.accent2,border:'none',borderRadius:6,color:btRunning?C.text2:'#fff',fontFamily:'Space Mono,monospace',fontWeight:700,fontSize:11,cursor:btRunning?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
                  {btRunning?<><Spinner size={12}/> Running Backtest...</>:'▶ Run Backtest'}
                </button>
              </div>
            </div>
          )}
        </div>

        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {loading&&(
            <div style={{...card(),padding:40,display:'flex',flexDirection:'column',alignItems:'center',gap:12}}>
              <Spinner size={28}/>
              <span style={{color:C.text2,fontSize:12,fontFamily:'Space Mono,monospace'}}>Claude AI is analyzing your strategy...</span>
            </div>
          )}
          {insight&&!loading&&(
            <div style={{...card(),animation:'fadeUp .3s ease'}}>
              <div style={cardHeader()}>
                <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.accent,textTransform:'uppercase',letterSpacing:'.1em'}}>⚡ AI Strategy Insights</span>
                <div style={{display:'flex',alignItems:'center',gap:6}}>
                  <span style={{fontSize:10,color:C.text2,fontFamily:'Space Mono,monospace'}}>Rating:</span>
                  <span style={{fontSize:20,fontFamily:'Syne,sans-serif',fontWeight:800,color:insight.rating>=7?C.accent:insight.rating>=5?C.accent3:C.danger}}>{insight.rating}/10</span>
                </div>
              </div>
              <div style={{padding:14,display:'flex',flexDirection:'column',gap:10}}>
                <p style={{fontSize:11,color:C.text,lineHeight:1.6,padding:10,background:C.bg2,borderRadius:6,borderLeft:`3px solid ${C.accent}`,fontFamily:'Space Mono,monospace'}}>{insight.summary}</p>
                <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                  <div style={{background:'rgba(0,212,170,.05)',border:'1px solid rgba(0,212,170,.15)',borderRadius:8,padding:10}}>
                    <div style={{fontSize:9,color:C.accent,textTransform:'uppercase',marginBottom:5,fontFamily:'Space Mono,monospace'}}>✓ Strengths</div>
                    {(insight.strengths||[]).map((s,i)=><div key={i} style={{fontSize:10,color:C.text2,marginBottom:2,fontFamily:'Space Mono,monospace'}}>• {s}</div>)}
                  </div>
                  <div style={{background:'rgba(255,69,96,.05)',border:'1px solid rgba(255,69,96,.15)',borderRadius:8,padding:10}}>
                    <div style={{fontSize:9,color:C.danger,textTransform:'uppercase',marginBottom:5,fontFamily:'Space Mono,monospace'}}>✗ Weaknesses</div>
                    {(insight.weaknesses||[]).map((w,i)=><div key={i} style={{fontSize:10,color:C.text2,marginBottom:2,fontFamily:'Space Mono,monospace'}}>• {w}</div>)}
                  </div>
                </div>
                <div style={{display:'flex',gap:8}}>
                  {[['Best Markets',insight.bestMarkets,C.text],['Risk Level',insight.riskLevel,insight.riskLevel==='High'?C.danger:insight.riskLevel==='Low'?C.accent:C.accent3]].map(([l,v,c])=>(
                    <div key={l} style={{flex:1,...card(),padding:10}}>
                      <div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div>
                      <div style={{fontSize:11,color:c,marginTop:3,fontFamily:'Space Mono,monospace'}}>{v}</div>
                    </div>
                  ))}
                </div>
                {(insight.improvements||[]).map((imp,i)=>(
                  <div key={i} style={{fontSize:10,color:C.text,paddingLeft:8,borderLeft:`2px solid ${C.accent2}`,fontFamily:'Space Mono,monospace'}}>→ {imp}</div>
                ))}
              </div>
            </div>
          )}
          {btResult&&(
            <div style={{...card(),animation:'fadeUp .3s ease'}}>
              <div style={cardHeader()}>
                <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Backtest Results</span>
                <span style={tag('green')}>Complete</span>
              </div>
              <div style={{padding:14}}>
                <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8,marginBottom:12}}>
                  {[['Net Profit',`+$${btResult.profit}`,C.accent],['Win Rate',`${btResult.winRate}%`,C.accent],['Prof. Factor',btResult.pf.toFixed(2),C.accent2],['Max DD',`${btResult.dd}%`,C.danger],['Sharpe',btResult.sharpe.toFixed(2),C.accent4],['Trades',btResult.trades,C.text]].map(([l,v,c])=>(
                    <div key={l} style={{background:C.bg2,borderRadius:6,padding:'7px 9px'}}>
                      <div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div>
                      <div style={{fontSize:15,fontFamily:'Syne,sans-serif',fontWeight:800,color:c,marginTop:2}}>{v}</div>
                    </div>
                  ))}
                </div>
                <div style={{fontSize:9,color:C.text3,textTransform:'uppercase',marginBottom:5,fontFamily:'Space Mono,monospace'}}>Equity Curve</div>
                <Sparkline data={btResult.equity} w={300} h={55}/>
              </div>
            </div>
          )}
          {!insight&&!loading&&(
            <div style={{...card(),padding:32,display:'flex',flexDirection:'column',alignItems:'center',gap:10,opacity:.45}}>
              <div style={{fontSize:32}}>⚡</div>
              <div style={{fontSize:12,color:C.text2,textAlign:'center',fontFamily:'Space Mono,monospace'}}>Enter your strategy and click "Get AI Insights" to receive detailed analysis before backtesting</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ─── HISTORY SCREEN ────────────────────────────────────────────────────── */
function HistoryScreen() {
  const [filter,setFilter]=useState('all');
  const [aiRev,setAiRev]=useState(null);
  const [loading,setLoading]=useState(false);
  const filtered=filter==='all'?HIST_TRADES:filter==='win'?HIST_TRADES.filter(t=>t.pnl>0):HIST_TRADES.filter(t=>t.pnl<0);

  const getReview=async()=>{
    setLoading(true);
    try{
      const r=await callClaude([{role:'user',content:`Review this trading history: ${JSON.stringify(HIST_TRADES)}\nReturn JSON:{summary:string,patterns:[],suggestions:[],overallGrade:string}`}],'Trading performance analyst. ONLY valid JSON.');
      setAiRev(JSON.parse(r.replace(/```json|```/g,'').trim()));
    }catch{setAiRev({summary:'Strong gold trades driving most profits. Forex scalps need tighter risk management.',patterns:['XAUUSD is your best instrument','Sell trades underperform buys'],suggestions:['Focus more on gold','Increase position size on high-confidence setups'],overallGrade:'B+'});}
    setLoading(false);
  };

  return(
    <div style={{display:'grid',gridTemplateColumns:'2fr 1fr',gap:14,animation:'fadeUp .35s ease'}}>
      <div style={card()}>
        <div style={cardHeader()}>
          <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Trade History</span>
          <div style={{display:'flex',gap:6}}>
            {[['all','All'],['win','Winners'],['loss','Losers']].map(([v,l])=>(
              <button key={v} onClick={()=>setFilter(v)} style={{...btn({padding:'3px 10px',fontSize:9}),borderColor:filter===v?C.accent:C.border2,color:filter===v?C.accent:C.text2}}>{l}</button>
            ))}
          </div>
        </div>
        <table style={{width:'100%',borderCollapse:'collapse',fontSize:11,fontFamily:'Space Mono,monospace'}}>
          <thead><tr style={{borderBottom:`1px solid ${C.border}`}}>
            {['Date','Symbol','Type','Entry','Exit','P&L','%'].map(h=>(
              <th key={h} style={{padding:'7px 13px',textAlign:'left',color:C.text3,fontWeight:400,fontSize:9,textTransform:'uppercase'}}>{h}</th>
            ))}
          </tr></thead>
          <tbody>{filtered.map(t=>(
            <tr key={t.id} style={{borderBottom:`1px solid ${C.border}`}}>
              <td style={{padding:'9px 13px',color:C.text3}}>{t.date}</td>
              <td style={{fontWeight:700}}>{t.symbol}</td>
              <td><span style={tag(t.type==='BUY'?'green':'red')}>{t.type}</span></td>
              <td style={{color:C.text2}}>{t.entry}</td>
              <td style={{color:C.text2}}>{t.exit}</td>
              <td style={{fontWeight:700,color:t.pnl>0?C.accent:C.danger}}>{t.pnl>0?'+':''}${t.pnl.toFixed(2)}</td>
              <td style={{color:t.pnlPct>0?C.accent:C.danger}}>{t.pnlPct>0?'+':''}{t.pnlPct}%</td>
            </tr>
          ))}</tbody>
        </table>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div style={card()}>
          <div style={cardHeader()}><span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>Stats</span></div>
          <div style={{padding:14,display:'flex',flexDirection:'column',gap:8}}>
            {[['Total Trades','21'],['Winners','15 (71.4%)'],['Losers','6 (28.6%)'],['Total P&L','+$1,156'],['Best Trade','+$420 XAUUSD'],['Avg Win','+$77'],['Avg Loss','-$12']].map(([l,v])=>(
              <div key={l} style={{display:'flex',justifyContent:'space-between'}}>
                <span style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace'}}>{l}</span>
                <span style={{fontSize:10,fontFamily:'Space Mono,monospace',color:C.text}}>{v}</span>
              </div>
            ))}
          </div>
        </div>
        <button onClick={getReview} disabled={loading} style={{padding:11,background:loading?C.surface:C.accent,border:'none',borderRadius:7,color:loading?C.text2:'#000',fontFamily:'Space Mono,monospace',fontWeight:900,fontSize:11,cursor:loading?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
          {loading?<><Spinner size={12}/> Analyzing...</>:'⚡ AI Performance Review'}
        </button>
        {aiRev&&(
          <div style={{...card(),animation:'fadeUp .3s ease'}}>
            <div style={cardHeader()}>
              <span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>AI Review</span>
              <span style={tag('purple')}>{aiRev.overallGrade}</span>
            </div>
            <div style={{padding:12,display:'flex',flexDirection:'column',gap:7}}>
              <p style={{fontSize:10,color:C.text2,lineHeight:1.6,fontFamily:'Space Mono,monospace'}}>{aiRev.summary}</p>
              {(aiRev.suggestions||[]).map((s,i)=>(
                <div key={i} style={{fontSize:10,color:C.text,paddingLeft:7,borderLeft:`2px solid ${C.accent2}`,fontFamily:'Space Mono,monospace'}}>→ {s}</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── AI CHAT ───────────────────────────────────────────────────────────── */
function AIChatScreen() {
  const [msgs,setMsgs]=useState([{role:'assistant',content:"Hello! I'm your Aegis-Trade AI assistant powered by Claude. I can analyze markets, explain strategies, review your performance, or answer any trading question. What would you like to know?"}]);
  const [input2,setInput]=useState('');
  const [loading,setLoading]=useState(false);
  const endRef=useRef();
  useEffect(()=>endRef.current?.scrollIntoView({behavior:'smooth'}),[msgs]);

  const send=async()=>{
    if(!input2.trim()||loading)return;
    const um={role:'user',content:input2.trim()};
    setMsgs(p=>[...p,um]);setInput('');setLoading(true);
    const history=[...msgs,um].map(m=>({role:m.role,content:m.content}));
    const reply=await callClaude(history,'Expert AI trading assistant. Deep knowledge of forex, gold, crypto, technical analysis, risk management. Be concise and practical.');
    setMsgs(p=>[...p,{role:'assistant',content:reply}]);
    setLoading(false);
  };

  const SUGG=['Analyze gold right now','Best XAUUSD scalping hours','Explain RSI divergence','Improve my win rate','What moves gold prices?','Position sizing formula'];

  return(
    <div style={{display:'flex',flexDirection:'column',height:'calc(100vh - 140px)'}}>
      <div style={{...card(),flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        <div style={cardHeader()}>
          <div style={{display:'flex',alignItems:'center',gap:9}}>
            <div style={{width:26,height:26,borderRadius:'50%',background:'linear-gradient(135deg,#00d4aa,#0099ff)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12}}>⚡</div>
            <span style={{fontFamily:'Syne,sans-serif',fontWeight:700,fontSize:14}}>Trading AI Assistant</span>
          </div>
          <span style={tag('green')}><span style={{width:5,height:5,borderRadius:'50%',background:C.accent,display:'inline-block',marginRight:3,animation:'pulse 2s infinite'}}/>Online</span>
        </div>
        <div style={{flex:1,overflowY:'auto',padding:14,display:'flex',flexDirection:'column',gap:10}}>
          {msgs.map((m,i)=>(
            <div key={i} style={{display:'flex',gap:9,flexDirection:m.role==='user'?'row-reverse':'row',animation:'fadeUp .25s ease'}}>
              {m.role==='assistant'&&<div style={{width:26,height:26,borderRadius:'50%',background:'linear-gradient(135deg,#00d4aa,#0099ff)',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11}}>⚡</div>}
              <div style={{maxWidth:'76%',padding:'10px 13px',borderRadius:m.role==='user'?'14px 14px 4px 14px':'4px 14px 14px 14px',background:m.role==='user'?C.accent2:C.surface2,color:m.role==='user'?'#fff':C.text,fontSize:11,lineHeight:1.65,fontFamily:'Space Mono,monospace',border:m.role==='assistant'?`1px solid ${C.border}`:'none'}}>
                {m.content}
              </div>
            </div>
          ))}
          {loading&&(
            <div style={{display:'flex',gap:9}}>
              <div style={{width:26,height:26,borderRadius:'50%',background:'linear-gradient(135deg,#00d4aa,#0099ff)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11}}>⚡</div>
              <div style={{padding:'10px 13px',background:C.surface2,borderRadius:'4px 14px 14px 14px',border:`1px solid ${C.border}`,display:'flex',gap:5,alignItems:'center'}}>
                {[0,1,2].map(i=><div key={i} style={{width:6,height:6,borderRadius:'50%',background:C.accent,animation:`pulse 1.2s infinite ${i*.2}s`}}/>)}
              </div>
            </div>
          )}
          <div ref={endRef}/>
        </div>
        {msgs.length<=1&&(
          <div style={{padding:'0 14px 10px',display:'flex',flexWrap:'wrap',gap:6}}>
            {SUGG.map(s=><button key={s} onClick={()=>setInput(s)} style={btn({fontSize:9})}>{s}</button>)}
          </div>
        )}
        <div style={{padding:'11px 14px',borderTop:`1px solid ${C.border}`,display:'flex',gap:8}}>
          <input style={{...input(),flex:1}} placeholder="Ask anything about trading..." value={input2} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()}/>
          <button onClick={send} disabled={loading} style={{padding:'8px 18px',background:input2.trim()&&!loading?C.accent:C.surface,border:`1px solid ${input2.trim()&&!loading?C.accent:C.border2}`,borderRadius:6,color:input2.trim()&&!loading?'#000':C.text3,fontFamily:'Space Mono,monospace',fontWeight:700,fontSize:11,cursor:input2.trim()&&!loading?'pointer':'default',transition:'all .2s',flexShrink:0}}>Send ▶</button>
        </div>
      </div>
    </div>
  );
}

/* ─── CONNECTIONS SCREEN ────────────────────────────────────────────────── */
function ConnectionsScreen({tvConnected,setTvConnected,mt5Connected,setMt5Connected}) {
  const [tvUser,setTvUser]=useState('');
  const [tvPass,setTvPass]=useState('');
  const [srv,setSrv]=useState('');
  const [acc,setAcc]=useState('');
  const [mpass,setMpass]=useState('');
  const [conn,setConn]=useState('');

  const connect=(type)=>{
    setConn(type);
    setTimeout(()=>{ type==='tv'?setTvConnected(true):setMt5Connected(true); setConn(''); },2000);
  };

  return(
    <div style={{display:'flex',flexDirection:'column',gap:14,maxWidth:680,animation:'fadeUp .35s ease'}}>
      <div style={{padding:'10px 14px',background:'rgba(0,212,170,.06)',border:'1px solid rgba(0,212,170,.18)',borderRadius:8,borderLeft:`3px solid ${C.accent}`}}>
        <span style={{fontSize:11,color:C.text2,fontFamily:'Space Mono,monospace',lineHeight:1.65}}>Connect your TradingView and MetaTrader 5 accounts to enable autonomous AI trading. Credentials are encrypted end-to-end.</span>
      </div>

      {/* TradingView */}
      <div style={card()}>
        <div style={cardHeader()}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:30,height:30,borderRadius:7,background:'#2962ff',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,fontWeight:900,color:'#fff'}}>TV</div>
            <div><div style={{fontFamily:'Syne,sans-serif',fontWeight:700,fontSize:14}}>TradingView</div><div style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace'}}>Chart analysis & signal source</div></div>
          </div>
          <span style={tag(tvConnected?'green':'red')}>{tvConnected?'● Connected':'○ Offline'}</span>
        </div>
        {!tvConnected?(
          <div style={{padding:14,display:'flex',flexDirection:'column',gap:9}}>
            <input style={input()} placeholder="TradingView username" value={tvUser} onChange={e=>setTvUser(e.target.value)} autoComplete="off"/>
            <input style={input()} type="password" placeholder="Password" value={tvPass} onChange={e=>setTvPass(e.target.value)}/>
            <button onClick={()=>connect('tv')} disabled={conn==='tv'} style={{padding:11,background:C.accent2,border:'none',borderRadius:7,color:'#fff',fontFamily:'Space Mono,monospace',fontWeight:700,fontSize:11,cursor:conn==='tv'?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
              {conn==='tv'?<><Spinner size={12}/> Connecting...</>:'Connect TradingView'}
            </button>
          </div>
        ):(
          <div style={{padding:14,display:'flex',flexDirection:'column',gap:9}}>
            <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>{['EURUSD','GBPUSD','XAUUSD','BTCUSD','NASDAQ'].map(s=><span key={s} style={tag('blue')}>{s}</span>)}</div>
            <span style={{fontSize:10,color:C.text2,fontFamily:'Space Mono,monospace'}}>Streaming 8 symbols · M1 M5 H1 H4 D1 · EMA RSI MACD BB</span>
            <button onClick={()=>setTvConnected(false)} style={{alignSelf:'flex-start',...btn({borderColor:C.danger,color:C.danger})}}>Disconnect</button>
          </div>
        )}
      </div>

      {/* MT5 */}
      <div style={card()}>
        <div style={cardHeader()}>
          <div style={{display:'flex',alignItems:'center',gap:10}}>
            <div style={{width:30,height:30,borderRadius:7,background:'#1a3a5c',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:900,color:'#4fa8d8'}}>MT5</div>
            <div><div style={{fontFamily:'Syne,sans-serif',fontWeight:700,fontSize:14}}>MetaTrader 5</div><div style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace'}}>Trade execution engine</div></div>
          </div>
          <span style={tag(mt5Connected?'green':'red')}>{mt5Connected?'● Connected':'○ Offline'}</span>
        </div>
        {!mt5Connected?(
          <div style={{padding:14,display:'flex',flexDirection:'column',gap:9}}>
            <input style={input()} placeholder="Broker server (e.g. ICMarkets-Live02)" value={srv} onChange={e=>setSrv(e.target.value)} autoComplete="off"/>
            <input style={input()} placeholder="Account login number" value={acc} onChange={e=>setAcc(e.target.value)}/>
            <input style={input()} type="password" placeholder="Password" value={mpass} onChange={e=>setMpass(e.target.value)}/>
            <button onClick={()=>connect('mt5')} disabled={conn==='mt5'} style={{padding:11,background:'#1a3a5c',border:`1px solid #253650`,borderRadius:7,color:'#4fa8d8',fontFamily:'Space Mono,monospace',fontWeight:700,fontSize:11,cursor:conn==='mt5'?'not-allowed':'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
              {conn==='mt5'?<><Spinner size={12}/> Connecting...</>:'Connect MetaTrader 5'}
            </button>
          </div>
        ):(
          <div style={{padding:14,display:'flex',flexDirection:'column',gap:9}}>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
              {[['Balance','$12,847.50'],['Leverage','1:100'],['Account','Live']].map(([l,v])=>(
                <div key={l} style={{background:C.bg2,borderRadius:6,padding:'8px 10px'}}>
                  <div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace'}}>{l}</div>
                  <div style={{fontSize:13,fontFamily:'Syne,sans-serif',fontWeight:700,marginTop:2}}>{v}</div>
                </div>
              ))}
            </div>
            <button onClick={()=>setMt5Connected(false)} style={{alignSelf:'flex-start',...btn({borderColor:C.danger,color:C.danger})}}>Disconnect</button>
          </div>
        )}
      </div>

      {/* Risk management */}
      <div style={card()}>
        <div style={cardHeader()}><span style={{fontFamily:'Space Mono',fontSize:10,fontWeight:700,color:C.text2,textTransform:'uppercase',letterSpacing:'.1em'}}>⚙ Risk Management Settings</span></div>
        <div style={{padding:14,display:'flex',flexDirection:'column',gap:12}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10}}>
            {[['Max Risk per Trade (%)','1.0'],['Max Daily Drawdown (%)','5.0'],['Max Open Trades','5'],['Max Lot Size','1.0'],['Stop on Drawdown (%)','10.0'],['Daily Profit Target (%)','3.0']].map(([l,d])=>(
              <div key={l}><div style={{fontSize:8,color:C.text3,textTransform:'uppercase',fontFamily:'Space Mono,monospace',marginBottom:4}}>{l}</div><input style={{...input(),padding:'7px 10px'}} defaultValue={d}/></div>
            ))}
          </div>
          <button style={{padding:10,background:C.accent,border:'none',borderRadius:7,color:'#000',fontFamily:'Space Mono,monospace',fontWeight:900,fontSize:11,cursor:'pointer',alignSelf:'flex-start',paddingLeft:20,paddingRight:20}}>Save Risk Settings</button>
        </div>
      </div>
    </div>
  );
}

/* ─── ROOT APP ──────────────────────────────────────────────────────────── */
export default function App() {
  const [screen,setScreen]           = useState('dashboard');
  const [tvConnected,setTvConn]      = useState(false);
  const [mt5Connected,setMt5Conn]    = useState(false);

  // Listen for navigation commands from Electron menu shortcuts
  useEffect(()=>{
    const api = window.electronAPI;
    if(api?.onNavigate) api.onNavigate(s=>setScreen(s));
  },[]);

  return (
    <>
      <style>{GLOBAL_CSS}</style>
      <div style={{height:'100vh',display:'flex',flexDirection:'column',background:C.bg,overflow:'hidden'}}>
        <TitleBar screen={screen} setScreen={setScreen} tvConnected={tvConnected} mt5Connected={mt5Connected}/>
        <TickerBar/>
        <div style={{flex:1,overflowY:'auto',padding:'14px 20px',paddingBottom:20}}>
          {screen==='dashboard'&&<DashboardScreen tvConnected={tvConnected} mt5Connected={mt5Connected} setScreen={setScreen}/>}
          {screen==='gold'     &&<GoldScalperScreen/>}
          {screen==='strategy' &&<StrategyScreen/>}
          {screen==='history'  &&<HistoryScreen/>}
          {screen==='ai'       &&<AIChatScreen/>}
          {screen==='connect'  &&<ConnectionsScreen tvConnected={tvConnected} setTvConnected={setTvConn} mt5Connected={mt5Connected} setMt5Connected={setMt5Conn}/>}
        </div>
        <div style={{padding:'6px 18px',borderTop:`1px solid ${C.border}`,display:'flex',justifyContent:'space-between',background:C.bg2,flexShrink:0}}>
          <span style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace'}}>AEGIS-TRADE · Powered by Claude AI · Educational purposes only · Not financial advice</span>
          <span style={{fontSize:9,color:C.text3,fontFamily:'Space Mono,monospace'}}>v2.5.0 · Gold Scalper Edition</span>
        </div>
      </div>
    </>
  );
}
