// src/renderer/utils.js  — shared helpers for all screens

export const C = {
  bg:'#080c10', bg2:'#0d1117', surface:'#141b26', surface2:'#1a2333',
  border:'#1e2d42', border2:'#253650',
  accent:'#00d4aa', accent2:'#0099ff', accent3:'#ff6b35', accent4:'#9b59ff',
  danger:'#ff4560', gold:'#ffd700', goldDark:'#b8860b',
  text:'#e8f0fe', text2:'#8899aa', text3:'#4d6070',
};

export const MOCK_SYMBOLS = ['EURUSD','GBPUSD','XAUUSD','BTCUSD','NASDAQ','SPX500','USDJPY','AUDUSD'];

export const MOCK_TRADES = [
  { id:1, symbol:'EURUSD', type:'BUY',  entry:1.0842, current:1.0871, sl:1.0810, tp:1.0900, lots:0.5,  pnl:+14.5,  pnlPct:+0.27, time:'09:42' },
  { id:2, symbol:'XAUUSD', type:'SELL', entry:2341.50,current:2328.20,sl:2360.0, tp:2300.0, lots:0.1,  pnl:+133.0, pnlPct:+0.57, time:'10:15' },
  { id:3, symbol:'GBPUSD', type:'BUY',  entry:1.2680, current:1.2695, sl:1.2640, tp:1.2750, lots:0.3,  pnl:+4.5,   pnlPct:+0.12, time:'11:02' },
  { id:4, symbol:'BTCUSD', type:'BUY',  entry:67250,  current:68100,  sl:65000,  tp:72000,  lots:0.01, pnl:+85.0,  pnlPct:+1.26, time:'08:30' },
];

export const HIST_TRADES = [
  { id:10, symbol:'EURUSD', type:'BUY',  entry:1.0780, exit:1.0842, pnl:+31.0,  pnlPct:+0.57, date:'Mar 19' },
  { id:11, symbol:'NASDAQ', type:'SELL', entry:18420,  exit:18210,  pnl:+210.0, pnlPct:+1.14, date:'Mar 19' },
  { id:12, symbol:'XAUUSD', type:'BUY',  entry:2298.0, exit:2340.0, pnl:+420.0, pnlPct:+1.83, date:'Mar 18' },
  { id:13, symbol:'GBPUSD', type:'SELL', entry:1.2710, exit:1.2760, pnl:-15.0,  pnlPct:-0.39, date:'Mar 18' },
  { id:14, symbol:'USDJPY', type:'BUY',  entry:149.80, exit:150.40, pnl:+60.0,  pnlPct:+0.40, date:'Mar 17' },
  { id:15, symbol:'BTCUSD', type:'BUY',  entry:65100,  exit:67250,  pnl:+215.0, pnlPct:+3.30, date:'Mar 17' },
];

export const SCALP_SETUPS = [
  { id:1, name:'London Breakout', tf:'M5', winRate:72, avgPips:8,  risk:'Low',    desc:'Trade the first 30-min London range break with volume confirmation.' },
  { id:2, name:'NY Kill Zone',    tf:'M1', winRate:68, avgPips:5,  risk:'Medium', desc:'Scalp reversals at NY open when gold reacts to USD data.' },
  { id:3, name:'EMA Ribbon Surf', tf:'M5', winRate:65, avgPips:7,  risk:'Low',    desc:'Trade with EMA 8/13/21 ribbon on pullbacks during trend.' },
  { id:4, name:'Spike & Fade',    tf:'M1', winRate:58, avgPips:10, risk:'High',   desc:'Fade sharp impulsive spikes when RSI hits extreme levels.' },
  { id:5, name:'Support Bounce',  tf:'M5', winRate:70, avgPips:6,  risk:'Low',    desc:'Buy at key intraday support zones during bullish sessions.' },
];

export const generatePriceSeries = (base, len=80) => {
  const arr = [base];
  for (let i=1;i<len;i++) {
    const d = (Math.random()-0.49)*base*0.003;
    arr.push(Math.max(base*0.95, arr[i-1]+d));
  }
  return arr;
};

export const callClaude = async (messages, system) => {
  const r = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST',
    headers:{ 'Content-Type':'application/json' },
    body: JSON.stringify({ model:'claude-sonnet-4-20250514', max_tokens:1000, system, messages }),
  });
  const d = await r.json();
  return d.content?.map(b=>b.text||'').join('') || 'No response.';
};

// Reusable styled component helpers (inline style factories)
export const card = (extra={}) => ({
  background:C.surface, border:`1px solid ${C.border}`, borderRadius:10,
  overflow:'hidden', ...extra,
});

export const cardHeader = (extra={}) => ({
  padding:'10px 14px', borderBottom:`1px solid ${C.border}`,
  display:'flex', alignItems:'center', justifyContent:'space-between',
  background:C.surface2, ...extra,
});

export const btn = (extra={}) => ({
  display:'inline-flex', alignItems:'center', gap:5,
  padding:'7px 14px', borderRadius:6, border:`1px solid ${C.border2}`,
  background:C.surface, color:C.text, fontFamily:'Space Mono, monospace',
  fontSize:10, letterSpacing:'0.05em', cursor:'pointer',
  transition:'all 0.15s', textTransform:'uppercase', ...extra,
});

export const input = (extra={}) => ({
  background:C.bg2, border:`1px solid ${C.border}`,
  color:C.text, fontFamily:'Space Mono, monospace', fontSize:11,
  padding:'9px 12px', borderRadius:6, outline:'none', width:'100%', ...extra,
});

export const tag = (type, extra={}) => {
  const map = {
    green:  { bg:'rgba(0,212,170,0.1)',   color:C.accent,  border:'rgba(0,212,170,0.2)' },
    red:    { bg:'rgba(255,69,96,0.1)',   color:C.danger,  border:'rgba(255,69,96,0.2)' },
    blue:   { bg:'rgba(0,153,255,0.1)',   color:C.accent2, border:'rgba(0,153,255,0.2)' },
    purple: { bg:'rgba(155,89,255,0.1)',  color:C.accent4, border:'rgba(155,89,255,0.2)' },
    orange: { bg:'rgba(255,107,53,0.1)',  color:C.accent3, border:'rgba(255,107,53,0.2)' },
    gold:   { bg:'rgba(255,215,0,0.1)',   color:C.gold,    border:'rgba(255,215,0,0.2)' },
  };
  const t = map[type]||map.blue;
  return {
    display:'inline-flex', alignItems:'center', gap:3,
    padding:'2px 7px', borderRadius:4, fontSize:9,
    fontFamily:'Space Mono, monospace', fontWeight:700, textTransform:'uppercase',
    letterSpacing:'0.05em', background:t.bg, color:t.color,
    border:`1px solid ${t.border}`, ...extra,
  };
};
