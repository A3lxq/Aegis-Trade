// src/renderer/components/TickerBar.jsx
import React, { useState, useEffect } from 'react';

const BASE_PRICES = {
  'EURUSD':1.0871,'GBPUSD':1.2695,'XAUUSD':2341.50,'BTCUSD':68100,
  'NASDAQ':18542,'SPX500':5248,'USDJPY':150.42,'AUDUSD':0.6542,
  'OIL/WTI':82.40,'DXY':103.82,
};

export default function TickerBar() {
  const [prices, setPrices] = useState(BASE_PRICES);

  useEffect(() => {
    const iv = setInterval(() => {
      setPrices(prev => {
        const next = { ...prev };
        Object.keys(next).forEach(sym => {
          const delta = (Math.random() - 0.499) * next[sym] * 0.0008;
          next[sym] = parseFloat((next[sym] + delta).toFixed(sym === 'EURUSD' || sym === 'GBPUSD' || sym === 'AUDUSD' ? 4 : 2));
        });
        return next;
      });
    }, 900);
    return () => clearInterval(iv);
  }, []);

  const items = Object.entries(prices).map(([sym, price]) => {
    const base  = BASE_PRICES[sym];
    const chg   = ((price - base) / base * 100).toFixed(2);
    return { sym, price, chg };
  });

  const doubled = [...items, ...items];

  return (
    <div style={{
      background:'#0d1117', borderBottom:'1px solid #1e2d42',
      height:26, overflow:'hidden', display:'flex', alignItems:'center', flexShrink:0,
    }}>
      <div style={{
        display:'flex', animation:'ticker 35s linear infinite',
        whiteSpace:'nowrap',
      }}>
        {doubled.map((it, i) => {
          const up = parseFloat(it.chg) >= 0;
          return (
            <span key={i} style={{
              padding:'0 14px', fontSize:10, fontFamily:'Space Mono, monospace',
              display:'inline-flex', gap:7, alignItems:'center',
              borderRight:'1px solid #1e2d42',
            }}>
              <span style={{ color:'#8899aa' }}>{it.sym}</span>
              <span style={{ color:'#e8f0fe' }}>
                {it.sym==='EURUSD'||it.sym==='GBPUSD'||it.sym==='AUDUSD'
                  ? it.price.toFixed(4) : it.price.toFixed(2)}
              </span>
              <span style={{ color: up ? '#00d4aa' : '#ff4560' }}>
                {up ? '▲' : '▼'}{Math.abs(it.chg)}%
              </span>
            </span>
          );
        })}
      </div>
      <style>{`@keyframes ticker { from{transform:translateX(0)} to{transform:translateX(-50%)} }`}</style>
    </div>
  );
}
