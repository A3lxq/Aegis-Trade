// src/renderer/components/TitleBar.jsx
import React, { useState } from 'react';

const C = {
  bg: '#080c10', bg2: '#0d1117', border: '#1e2d42',
  accent: '#00d4aa', text: '#e8f0fe', text2: '#8899aa', text3: '#4d6070',
  danger: '#ff4560',
};

export default function TitleBar({ screen, setScreen, tvConnected, mt5Connected }) {
  const [hov, setHov] = useState(null);
  const api = window.electronAPI;

  const NAV = [
    { id:'dashboard', label:'Dashboard',    icon:'◉' },
    { id:'gold',      label:'Gold Scalper', icon:'🥇', gold: true },
    { id:'strategy',  label:'Strategies',   icon:'⚙' },
    { id:'history',   label:'History',      icon:'📊' },
    { id:'ai',        label:'AI Chat',      icon:'⚡' },
    { id:'connect',   label:'Connections',  icon:'🔗' },
  ];

  const btnStyle = (id) => ({
    display:'flex', alignItems:'center', gap:5,
    padding:'5px 12px', border:'none', background:'none', cursor:'pointer',
    color: screen===id ? (id==='gold'?'#ffd700':'#00d4aa') : '#8899aa',
    fontFamily:'Space Mono, monospace', fontSize:10,
    borderRadius:5, textTransform:'uppercase', letterSpacing:'0.07em',
    background: screen===id ? (id==='gold'?'rgba(255,215,0,0.08)':'rgba(0,212,170,0.08)') : 'none',
    transition:'all 0.15s',
    WebkitAppRegion: 'no-drag',
  });

  const winBtnStyle = (id, color) => ({
    width:12, height:12, borderRadius:'50%',
    background: hov==='controls' ? color : '#333',
    border:'none', cursor:'pointer',
    transition:'background 0.15s',
    WebkitAppRegion:'no-drag',
  });

  return (
    <div style={{
      height:42, background:C.bg2, borderBottom:`1px solid ${C.border}`,
      display:'flex', alignItems:'center', paddingLeft:12, paddingRight:12,
      WebkitAppRegion:'drag', flexShrink:0, gap:8,
    }}>
      {/* Window controls (macOS-style works on Windows too) */}
      <div style={{ display:'flex', gap:6, alignItems:'center', marginRight:8, WebkitAppRegion:'no-drag' }}
        onMouseEnter={() => setHov('controls')} onMouseLeave={() => setHov(null)}>
        <button style={winBtnStyle('close','#ff5f57')}   onClick={() => api?.close()}    title="Close" />
        <button style={winBtnStyle('min',  '#ffbd2e')}   onClick={() => api?.minimize()} title="Minimize" />
        <button style={winBtnStyle('max',  '#28c840')}   onClick={() => api?.maximize()} title="Maximize" />
      </div>

      {/* Logo */}
      <div style={{ display:'flex', alignItems:'center', gap:7, marginRight:10, WebkitAppRegion:'no-drag' }}>
        <div style={{ width:24, height:24, borderRadius:5, background:'linear-gradient(135deg,#00d4aa,#0099ff)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:11, fontWeight:900, color:'#000' }}>⚡</div>
        <span style={{ fontFamily:'Syne,sans-serif', fontWeight:800, fontSize:13, color:C.text, letterSpacing:'-0.02em' }}>
          Aegis<span style={{ color:'#00d4aa' }}>Trade</span>
        </span>
        <span style={{ fontSize:8, color:C.text3, fontFamily:'Space Mono', textTransform:'uppercase', letterSpacing:'0.1em' }}>Trader</span>
      </div>

      {/* Nav */}
      <nav style={{ display:'flex', gap:2, flex:1, WebkitAppRegion:'no-drag' }}>
        {NAV.map(n => (
          <button key={n.id} style={btnStyle(n.id)} onClick={() => setScreen(n.id)}>
            <span>{n.icon}</span><span>{n.label}</span>
          </button>
        ))}
      </nav>

      {/* Connection status */}
      <div style={{ display:'flex', gap:6, alignItems:'center', padding:'3px 8px', background:'#141b26', borderRadius:6, border:`1px solid ${C.border}`, WebkitAppRegion:'no-drag' }}>
        <div style={{ width:6, height:6, borderRadius:'50%', background: tvConnected?'#00d4aa':'#ff4560' }} />
        <span style={{ fontSize:9, fontFamily:'Space Mono', color:C.text2 }}>TV</span>
        <span style={{ fontSize:9, color:C.text3 }}>|</span>
        <div style={{ width:6, height:6, borderRadius:'50%', background: mt5Connected?'#00d4aa':'#ff4560' }} />
        <span style={{ fontSize:9, fontFamily:'Space Mono', color:C.text2 }}>MT5</span>
      </div>

      {/* Auto-trading badge */}
      {tvConnected && mt5Connected && (
        <div style={{ padding:'3px 10px', borderRadius:5, border:'1px solid rgba(0,212,170,0.3)', background:'rgba(0,212,170,0.08)', WebkitAppRegion:'no-drag' }}>
          <span style={{ fontSize:9, fontFamily:'Space Mono', color:'#00d4aa', fontWeight:700 }}>⚡ AUTO TRADING</span>
        </div>
      )}
    </div>
  );
}
