# Aegis-Trade v2.5.0 — Gold Scalper Edition
### Build Instructions: Android APK + Windows EXE

---

## PROJECT STRUCTURE

```
aegis-trade-apk/          ← Android APK (React Native + Expo)
aegis-trade-exe/          ← Windows EXE (Electron + React)
```

---

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## PART 1 — BUILD THE ANDROID APK
## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

### Prerequisites
- Node.js 18+ (https://nodejs.org)
- An Expo account (free) at https://expo.dev

### Step 1 — Install dependencies
```bash
cd aegis-trade-apk
npm install
npm install -g eas-cli
```

### Step 2 — Log in to Expo
```bash
eas login
# Enter your expo.dev credentials
```

### Step 3 — Create your EAS project
```bash
eas init
# This generates a projectId — it will be saved automatically to app.json
```

### Step 4 — Build the APK (cloud build — no Android Studio needed!)
```bash
# Debug APK (fastest, for testing):
eas build --platform android --profile preview

# Release APK (optimized):
eas build --platform android --profile production
```

The build runs in Expo's cloud. When it finishes (~5-10 mins):
- You'll get a download link for the `.apk` file
- Install it on any Android device: `adb install aegis-trade.apk`
  OR transfer the APK file to your phone and open it

### Optional: Build locally (requires Android Studio)
```bash
npm run android         # Run on connected device/emulator
expo run:android        # Build and run locally
```

### Sideload APK on Android
1. Copy APK to your Android phone
2. Go to Settings → Security → Install Unknown Apps → Allow
3. Open the APK file and tap Install

---

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## PART 2 — BUILD THE WINDOWS .EXE
## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

### Prerequisites
- Node.js 18+ (https://nodejs.org)
- Windows 10/11 recommended for building (can also build on Mac/Linux)

### Step 1 — Install dependencies
```bash
cd aegis-trade-exe
npm install
```

### Step 2 — Set up React entry point
Create `src/index.js` pointing to the renderer:
```bash
# Already included in the project
```

### Step 3 — Test in development mode
```bash
npm run dev
# Opens the app in Electron with live reload
```

### Step 4 — Build the .EXE installer
```bash
# Full NSIS installer (.exe setup wizard):
npm run build:exe

# Portable .exe (no installation needed, just double-click):
npm run build:portable
```

Output files appear in `dist-exe/`:
```
dist-exe/
  Aegis-Trade Setup 2.5.0.exe     ← Installer (recommended)
  Aegis-Trade 2.5.0.exe           ← Portable (single file)
```

### Step 5 — Distribute
- Share the `Setup` EXE for users who want a proper Windows install
  (creates desktop shortcut, Start Menu entry, Add/Remove Programs entry)
- Share the `Portable` EXE for users who just want to run it anywhere

### Build for both 64-bit and 32-bit Windows:
```bash
npm run build:exe:32     # 32-bit (x86) — for older systems
npm run build:exe        # 64-bit (x64) — default
```

---

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## CONFIGURATION
## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

### App Icon
Replace these files with your own 512×512 icon:
- `aegis-trade-apk/assets/icon.png`          (Android icon)
- `aegis-trade-apk/assets/adaptive-icon.png` (Android adaptive icon)
- `aegis-trade-exe/assets/icon.ico`          (Windows EXE icon)
- `aegis-trade-exe/assets/icon.png`          (Generic)

Use https://icon.kitchen or https://appicon.co to generate all sizes at once.

### App Name / Bundle ID
- Android: Edit `app.json` → `expo.android.package` (e.g. `com.yourname.trader`)
- Windows:  Edit `package.json` → `build.appId`

---

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## FEATURES
## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

### All Platforms
- ◉  Dashboard      — Live charts, AI signals, open positions, market scanner
- 🥇  Gold Scalper  — Dedicated XAUUSD scalping with M5 candlestick chart,
                       EMA 8/21, session tracker, AI scalp signals, quick trade panel,
                       5 curated setups, economic news calendar, live P&L tracking
- ⚙  Strategies     — Create/upload strategies, AI insights before backtest,
                       full backtesting engine with equity curve
- 📊  History        — Trade history with AI performance review
- ⚡  AI Chat        — Full Claude AI trading assistant (multi-turn)
- 🔗  Connections    — TradingView + MT5 login, risk management settings

### Windows EXE Extras
- Frameless custom titlebar with window controls
- Keyboard shortcuts (Ctrl+1 through Ctrl+6 for navigation)
- System menu integration
- Auto-updates ready (add electron-updater)

---

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## TROUBLESHOOTING
## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

### APK Build Fails
- Run `eas doctor` to check your setup
- Ensure you're logged in: `eas whoami`
- Check build logs at https://expo.dev/accounts/[username]/projects

### EXE Build Fails — "electron not found"
```bash
npm install electron --save-dev
```

### EXE Build Fails — "react-scripts not found"
```bash
npm install react-scripts
```

### App shows blank screen on Android
- Check that `INTERNET` permission is in `app.json`
- Ensure API calls use `https://` (not `http://`)

### AI signals not working
- The Claude API requires valid credentials
- In production, add your API key to a secure backend proxy
- Never hardcode API keys in mobile/desktop apps

---

## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
## SECURITY NOTE
## ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

For production deployment:
1. Create a backend proxy server (Node.js/Express) to handle Claude API calls
2. Store the Anthropic API key on the server, never in the app bundle
3. Add authentication to your proxy endpoint
4. The app calls YOUR server → YOUR server calls Claude API

Example proxy endpoint:
```
POST https://your-server.com/api/claude
Authorization: Bearer <user-token>
Body: { messages: [...], system: "..." }
```

---

## DISCLAIMER
This software is for educational purposes only.
Not financial advice. Trading involves significant risk of loss.
Always test strategies thoroughly before live trading.
